﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class tailor_ledger : Form
    {
        DataTable dta;
        private MySqlConnection con;
        public tailor_ledger()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void table_cusledger_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Preview_tailor_ledger edt = new Preview_tailor_ledger();
            int row = table_cusledger.CurrentRow.Index;

            // edt.txt_id.Text = Convert.ToString(products_table[0, row].Value);
            edt.txt_id.Text = Convert.ToString(table_cusledger[0, row].Value);
            edt.txt_name.Text = Convert.ToString(table_cusledger[1, row].Value);


            // edt.txt_pcode.Text = Convert.ToString(products_table[1, row].Value);
            edt.Show();
        }
        public void loadledger()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT t_id,t_name,t_balance FROM tailor_ledger GROUP BY t_id  ", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                table_cusledger.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            table_cusledger.DataSource = dta;
            table_cusledger.Columns[0].HeaderText = "tailor ID";
            table_cusledger.Columns[1].HeaderText = "tailor Name";
            table_cusledger.Columns[2].HeaderText = "tailor Bal";
           

            table_cusledger.Columns[0].Width = 300;
            table_cusledger.Columns[1].Width = 300;
            table_cusledger.Columns[2].Width = 300;
            
        }

        private void tailor_ledger_Load(object sender, EventArgs e)
        {
            loadledger();
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search";
            }
        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search")
            {
                txt_search.Text = "";
            }
        }

        private void txt_search_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("t_name LIKE '%" + txt_search.Text.ToString() + "%' "); //OR p_unit '%{1}%'
            table_cusledger.DataSource = dv;
        }
    }
}
