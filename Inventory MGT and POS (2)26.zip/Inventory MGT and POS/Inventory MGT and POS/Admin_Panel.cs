﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace Inventory_MGT_and_POS
{
    public partial class Admin_Panel : Form
    {
        DataTable dta;
        private MySqlConnection con;
        public Admin_Panel()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtUserName.Text) || string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                MessageBox.Show("Please input Username and Password", "Error");
            }
            else if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Password Does Not Match", "Error");
            }
            else
            {
                try
                {
                    //string query = "SELECT * FROM userinfo WHERE u_name = '" + txtUserName.Text + "'";
                    MySqlParameter[] prm = new MySqlParameter[1];

                    prm[0] = new MySqlParameter("uname", MySqlDbType.VarChar);
                    prm[0].Value = txtUserName.Text;

                    MySqlCommand cmnd = new MySqlCommand();
                    cmnd.Connection = con;
                    cmnd.CommandType = CommandType.StoredProcedure;
                    cmnd.CommandText = "signup_click";
                    cmnd.Parameters.AddRange(prm);

                    // MySqlCommand cmd = new MySqlCommand(query, con);
                    con.Open();

                    using (MySqlDataReader dr = cmnd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            MessageBox.Show("Username not available!");

                            dr.Close();
                        }

                        else
                        {
                            dr.Close();
                            dr.Dispose();
                            try
                            {
                                // insert_in_signup  string iquery = "INSERT INTO userinfo (u_name, u_password, date_created,last_login) VALUES ('" + txtUserName.Text + "', '" + Encrypt(txtPassword.Text) + "', Now(), Now())";
                                //   MySqlCommand mySqlCommand = new MySqlCommand(iquery, con);
                                MySqlParameter[] pms = new MySqlParameter[3];
                                pms[0] = new MySqlParameter("uname", MySqlDbType.VarChar);
                                pms[0].Value = txtUserName.Text;
                                pms[1] = new MySqlParameter("upassword", MySqlDbType.VarChar);
                                pms[1].Value = Encrypt(txtPassword.Text);
                                pms[2] = new MySqlParameter("uroll", MySqlDbType.VarChar);
                                pms[2].Value = comb_roll.Text;

                                MySqlCommand cmd = new MySqlCommand();
                                cmd.Connection = con;
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.CommandText = "insert_in_signup";
                                cmd.Parameters.AddRange(pms);


                                //con.Open();
                                cmd.ExecuteNonQuery();
                                cmd.Dispose();


                                // MySqlCommand commandDatabase = mySqlCommand;

                                // MySqlDataReader myReader = commandDatabase.ExecuteReader();
                                MessageBox.Show("Account Successfully Created!");
                                load_user();
                            }
                            catch (Exception ex)
                            {
                                con.Close();
                                MessageBox.Show(ex.Message);
                            }


                        }


                    }

                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //openFileDialog1.ShowDialog();
            //string filepath = openFileDialog1.FileName;
            //pictureBox1.Image = Image.FromFile(filepath);
        }

        private void Admin_Panel_Load(object sender, EventArgs e)
        {
            load_user();
        }
        public void load_user()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT u_id,u_name,u_roll,date_created,last_login FROM users", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                TablaProductos.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            TablaProductos.DataSource = dta;
            TablaProductos.Columns[0].HeaderText = "ID";
            TablaProductos.Columns[1].HeaderText = "Name";

            TablaProductos.Columns[2].HeaderText = "User Roll";
            TablaProductos.Columns[3].HeaderText = "Date Created";
            TablaProductos.Columns[4].HeaderText = "Last Login";


            TablaProductos.Columns[0].Width = 150;
            TablaProductos.Columns[1].Width = 150;
            TablaProductos.Columns[2].Width = 150;
            TablaProductos.Columns[3].Width = 150;
            TablaProductos.Columns[4].Width = 150;



        }
            static string Encrypt(string value)
        {
            //Using MD5 to encrypt a string
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                //Hash data
                byte[] data = md5.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(data);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
