﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class product_list : Form
    {
        DataTable dta;
        private MySqlConnection con;
        MySqlCommand cmd;
        public product_list()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void product_list_Load(object sender, EventArgs e)
        {
            load_products();
        }
        private void load_products()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_id,p_code,p_name,invo_num,p_desc,meter,total_gaj,per_gaj,p_purchase_price,supplier_name FROM products ORDER BY p_id ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "products");

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                products_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            products_table.DataSource = dta;

            products_table.Columns[0].HeaderText = "ID";
            products_table.Columns[1].HeaderText = "Code";
            products_table.Columns[2].HeaderText = "Product Name";
            products_table.Columns[3].HeaderText = "Invoice";
            products_table.Columns[4].HeaderText = "Description";
            products_table.Columns[5].HeaderText = "Meter";
            products_table.Columns[6].HeaderText = "Total Gaj";
            products_table.Columns[7].HeaderText = "Per Gaj";
            products_table.Columns[8].HeaderText = "Purchasing Price";
            products_table.Columns[9].HeaderText = "Supplier";


            products_table.Columns[0].Width = 40;
            products_table.Columns[1].Width = 60;
            products_table.Columns[2].Width = 80;
            products_table.Columns[3].Width = 90;
            products_table.Columns[4].Width = 120;
            products_table.Columns[5].Width = 50;
            products_table.Columns[6].Width = 50;
            products_table.Columns[7].Width = 50;
            products_table.Columns[8].Width = 80;
            products_table.Columns[9].Width = 80;

            //  products_table.Columns[5].DefaultCellStyle.Format = "N2";
            products_table.Columns[8].DefaultCellStyle.Format = "N2";
        }

        private void products_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            preview_product edt = new preview_product();
            int row = products_table.CurrentRow.Index;

            // edt.txt_id.Text = Convert.ToString(products_table[0, row].Value);
            edt.txt_name.Text = Convert.ToString(products_table[9, row].Value);

            edt.txt_invoice.Text = Convert.ToString(products_table[3, row].Value);
            // edt.txt_pcode.Text = Convert.ToString(products_table[1, row].Value);
            edt.Show();
        }

        private void txt_search_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Format("supplier_name LIKE '%" + txt_search.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            products_table.DataSource = dv;
        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search")
            {
                txt_search.Text = "";
            }
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search";
            }
        }
    }
}
