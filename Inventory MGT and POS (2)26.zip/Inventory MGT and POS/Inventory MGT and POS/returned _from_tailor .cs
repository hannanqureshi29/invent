﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class returned__from_tailor : Form
    {
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        List<string> listOnit = new List<string>();
        private MySqlConnection con;
        public returned__from_tailor()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void max_invoice_id()
        {
            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(invo_num)+1 FROM stitchedproduct ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txt_invoice.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }
        //public void load()
        //{
        //    MySqlCommand cmd = new MySqlCommand("SELECT quantity FROM stitchedproduct ", con);
        //    try
        //    {
        //        MySqlDataAdapter sda = new MySqlDataAdapter();
        //        sda.SelectCommand = cmd;
        //        dta = new DataTable();
        //        sda.Fill(dta);
        //        BindingSource bsource = new BindingSource();

        //        bsource.DataSource = dta;
        //        Products_Table.DataSource = bsource;
        //        sda.Update(dta);
        //    }
        //    catch (Exception ex)
        //    {
        //        //con.Close();
        //        MessageBox.Show(ex.Message);
        //    }
        //}
            private void returned__from_tailor_Load(object sender, EventArgs e)
        {
            txt_issued.Value = System.DateTime.Now;
            max_invoice_id();
            tailor_name_search();
            // max_invoice_id();
            label20.Text = Login.u_name;

            //stiitched_table.Columns[0].Width = 75;
            //stiitched_table.Columns[1].Width = 75;
            //stiitched_table.Columns[2].Width = 50;
            //stiitched_table.Columns[3].Width = 100;
            //stiitched_table.Columns[4].Width = 80;
            //stiitched_table.Columns[5].Width = 100;
            // products_table.Columns[6].Width = 100;
        }
        public void tailor_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT t_name FROM saletotailor", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            comb_cname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }


        private void comb_cname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT t_phone,t_id FROM tailor WHERE t_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    //txt_phone.Text = dr.GetValue(0).ToString();
                    // txt_id.Text = dr.GetValue(1).ToString();
                }
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                for (int i = 0; i < stiitched_table.Rows.Count; i++)
                {
                    using (MySqlCommand cmd = new MySqlCommand("INSERT INTO stitchedproduct(p_code,invo_num,pur_date,p_name,t_id,t_name,category,sub_name,per_gaj,items,quantity,Total_update_quantity,per_piece,size,unit_price,total,total_items,grand_total) values(@code,@invo_num,NOW(),@pname,@tid,@tname,@category,@sub_name,@per_gaj,@items,@qty,@Total_update_quantity,@perpiece,@size,@unit_price,@total,@total_items,@grand_total)", con))
                    {
                        //  cmd.Parameters.AddWithValue("@code", txt_code.Text);
                        //cmd.Parameters.AddWithValue("@date", txt_issued.Value);
                        cmd.Parameters.AddWithValue("@tname", comb_cname.Text);
                        cmd.Parameters.AddWithValue("@tid", Convert.ToInt64(txt_tid.Text));

                        cmd.Parameters.AddWithValue("@category", txt_cat.Text);
                        // cmd.Parameters.AddWithValue("@tphone", txt_phone.Text);
                        // cmd.Parameters.AddWithValue("@purchase_price", txt_purchase.Text);
                        cmd.Parameters.AddWithValue("@code", stiitched_table.Rows[i].Cells[0].Value.ToString());
                        cmd.Parameters.AddWithValue("@pname", txt_product.Text);
                        cmd.Parameters.AddWithValue("@sub_name", txt_sub_product.Text);
                        cmd.Parameters.AddWithValue("@per_gaj", txt_per.Text);
                        cmd.Parameters.AddWithValue("@items", Convert.ToDouble(txt_result1.Text));
                        cmd.Parameters.AddWithValue("@size", Convert.ToDouble(stiitched_table.Rows[i].Cells[2].Value));
                        cmd.Parameters.AddWithValue("@qty", Convert.ToDouble(stiitched_table.Rows[i].Cells[3].Value));
                        cmd.Parameters.AddWithValue("@Total_update_quantity", Convert.ToDouble(stiitched_table.Rows[i].Cells[4].Value));
                        cmd.Parameters.AddWithValue("@perpiece", Convert.ToDouble(stiitched_table.Rows[i].Cells[5].Value));
                        cmd.Parameters.AddWithValue("@unit_price", Convert.ToInt32(stiitched_table.Rows[i].Cells[1].Value));
                        //cmd.Parameters.AddWithValue("@purchase_price", Convert.ToInt32(stiitched_table.Rows[i].Cells[6].Value));
                        cmd.Parameters.AddWithValue("@total", Convert.ToDouble(stiitched_table.Rows[i].Cells[6].Value));
                        cmd.Parameters.AddWithValue("@total_items", Convert.ToInt32(label14.Text));
                        cmd.Parameters.AddWithValue("@invo_num", Convert.ToInt32(txt_invoice.Text));
                        // cmd.Parameters.AddWithValue("@qty", Convert.ToDouble(stiitched_table.Rows[i].Cells[6].Value));
                        //  cmd.Parameters.AddWithValue("@Updatedstock", Convert.ToDouble(Table_purchase.Rows[i].Cells[6].Value));

                        // cmd.Parameters.AddWithValue("@subtotal", Convert.ToDouble(label9.Text));
                        //cmd.Parameters.AddWithValue("@taxamount", Convert.ToDouble(label11.Text));
                        cmd.Parameters.AddWithValue("@grand_total", Convert.ToDouble(txt_grand_total.Text));
                        //cmd.Parameters.AddWithValue("@cash_paid", Convert.ToDouble(txt_cash_rec.Text));
                       // cmd.Parameters.AddWithValue("@change", Convert.ToDouble(txt_change.Text));
                        //  cmd.Parameters.AddWithValue("@cashier", label5.Text.ToString());

                        cmd.ExecuteNonQuery();
                        // con.Close();
                        //2 cmd.Dispose();
                    }
                }
                for (int i = 0; i < stiitched_table.Rows.Count; i++)
                {

                    string query = ("UPDATE saletotailor set items ='"+txt_result1.Text+"'  WHERE p_code = '" + stiitched_table.Rows[i].Cells[0].Value + "' AND t_name ='"+ comb_cname.Text+ "' ;");
                    MySqlCommand cmnd = new MySqlCommand(query, con);
                    MySqlDataReader read;

                    read = cmnd.ExecuteReader();
                    // 
                    read.Close();
                    cmnd.Dispose();
                }
                for (int i = 0; i < stiitched_table.Rows.Count; i++)
                {

                    string query = ("UPDATE stitchedproduct set updated_stock ='" + txt_result.Text + "' WHERE p_code = '" + stiitched_table.Rows[i].Cells[0].Value + "' AND t_name ='" + comb_cname.Text + "' ORDER BY stitched_id DESC limit 1;");
                    MySqlCommand cmnd = new MySqlCommand(query, con);
                    MySqlDataReader read;

                    read = cmnd.ExecuteReader();
                    // 
                    read.Close();
                    cmnd.Dispose();
                }
                using (MySqlCommand cmd1 = new MySqlCommand("INSERT INTO tailor_ledger(t_id,t_name,date,t_credit,t_debit,t_balance)values(@tid,@tname,NOW(),@tcredit,@tdebit,@tbalance)", con))
                {
                    cmd1.Parameters.AddWithValue("@tid", Convert.ToInt64(txt_tid.Text));

                    cmd1.Parameters.AddWithValue("@tname", comb_cname.Text);
                    cmd1.Parameters.AddWithValue("@tcredit", 0);
                    cmd1.Parameters.AddWithValue("@tdebit", Convert.ToDouble(txt_grand_total.Text));
                    cmd1.Parameters.AddWithValue("@tbalance", txt_total_bill.Text);
                    //cmd1.Parameters.AddWithValue("@description", "Sale Against Invoice Number:" + txt_invoice.Text);

                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();
                }
                string query1 = ("UPDATE tailor SET t_rmnblnc ='" + txt_total_bill.Text + "' WHERE t_id = '" + txt_tid.Text + "' ;");
                MySqlCommand cmnd1 = new MySqlCommand(query1, con);
                MySqlDataReader read1;
                // MessageBox.Show("test");
                read1 = cmnd1.ExecuteReader();
                read1.Close();
                cmnd1.Dispose();


                con.Close();
                MessageBox.Show("Success");

              //  comb_cname.ResetText();
                //txt_phone.Clear();
                //txt_id.Clear();
              //  txt_product.Clear();
                // txt_purchase.Clear();

                stiitched_table.Rows.Clear();
                stiitched_table.Refresh();


               // txt_grand_total.Clear();
               // txt_grand_total.Refresh();
               // txt_cash_rec.Clear();
                //txt_change.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txt_stock_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_quantity_TextChanged(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(txt_quantity.Text))
            //{
            //    txt_quantity.Text = 0.ToString();
            //}
        }

        private void txt_quantity_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(txt_quantity.Text))
            //{
            //    txt_quantity.Text = 0.ToString();
            //}
        }

        private void txt_unitprice_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(txt_unitprice.Text))
            //{
            //    txt_unitprice.Text = 0.ToString();
            //}
        }

        private void txt_unitprice_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txt_qty.Text) || string.IsNullOrEmpty(txt_ptotal.Text))
            {
                MessageBox.Show("Please insert Quantity and Total ", "Error");
            }
            else
            {

                string[] row = { txt_item_code.Text, txt_product.Text };
                stiitched_table.Rows.Add(row);
                Double sum = 0;
                for (int i = 0; i < stiitched_table.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(stiitched_table.Rows[i].Cells[7].Value);
                }
                txt_grand_total.Text = sum.ToString("N2");
                label14.Text = (stiitched_table.RowCount).ToString();

                // combo_type.ResetText();   
                // combo_size.ResetText();
                // txt_quantity.Clear();
                // txt_purchase.Clear();
                //txt_unitprice.Clear();
                // txt_total.Clear();

                // max_invoice_id();
            }


        }


        private void txt_cash_rec_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    txt_change.Text = (Convert.ToDouble(txt_cash_rec.Text) - Convert.ToDouble(txt_grand_total.Text)).ToString("N2");
            //}
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // max_invoice_id();
        }

        private void txt_purchase_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    Int32 input1 = Convert.ToInt32(txt_purchase.Text);
            //    Int32 input2 = Convert.ToInt32(txt_quantity.Text);

            //    Int32 result = input1 * input2;

            //    txt_total.Text = result.ToString();
            //}
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            //if (Application.OpenForms.OfType<addnew_tailor>().Any())
            //{
            //    Application.OpenForms.OfType<addnew_tailor>().First().BringToFront();
            //}
            //else
            //{
            //    var dash = new addnew_tailor();
            //    dash.Show();

            //}
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //var dash = new load_stitched_product();
            //dash.Show();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void comb_cname_KeyDown_1(object sender, KeyEventArgs e)
        {

        }

        private void txt_code_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void comb_cname_KeyDown_2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products WHERE supplier_name = '" + txt_pcat.Text + "'", con);
                // con.Open();

                MySqlCommand cmd1 = new MySqlCommand("SELECT p_code,t_id FROM saletotailor WHERE t_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader reader = cmd1.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                    txt_tid.Text = reader.GetValue(1).ToString();
                }
                txt_item_code.AutoCompleteCustomSource = MyCollection;
                //con.Close();

                con.Close();
            }
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT t_rmnblnc FROM tailor WHERE t_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    txt_tayloe_amount.Text = dr.GetValue(0).ToString();
                    //txt_balan.Text = dr.GetValue(1).ToString();
                }
                con.Close();
            }
        }

        private void txt_item_code_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_name,sub_name,per_gaj,items,p_saleprice FROM saletotailor WHERE p_code = '" + txt_item_code.Text + "' AND t_name ='" + comb_cname.Text + "'", con); //ORDER BY COUNT(DISTINCT p_id )
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_product.Text = dr.GetValue(0).ToString();
                    txt_sub_product.Text = dr.GetValue(1).ToString();
                    txt_per.Text = dr.GetValue(2).ToString();
                    txt_items.Text = dr.GetValue(3).ToString();
                    txt_price.Text = dr.GetValue(4).ToString();
                    // txt_suit.Text = dr.GetValue(4).ToString();
                    // txt_unitprice.Text = dr.GetValue(3).ToString();
                }
                con.Close();
            }
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT ifnull((updated_stock),0) FROM stitchedproduct WHERE p_code = '" + txt_item_code.Text + "' AND t_name ='" + comb_cname.Text + "' ", con); //ORDER BY COUNT(DISTINCT p_id )
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_stock.Text = dr.GetValue(0).ToString();
                    
                }
                con.Close();
            }
        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_qty.Text.Trim() != string.Empty)
                {
                    Double A = Convert.ToDouble(txt_unitprice.Text);
                    Double B = Convert.ToDouble(txt_qty.Text);
                    txt_ptotal.Text = (A * B).ToString("N2");
                }
                else if (txt_qty.Text.Trim() == string.Empty)
                {
                    txt_ptotal.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //double u_stock;
            //double old_stock = Convert.ToDouble(txt_items.Text);
            //double new_stock = Convert.ToDouble(txt_qty.Text);

            //u_stock = old_stock - new_stock;
            //string[] row1 = { txt_items.Text, u_stock.ToString() };
            //hidden_table.Rows.Add(row1);

            //double u_stock1;
            // double old_stock1 = Convert.ToDouble(txt_stock.Text);
            //double new_stock1 = Convert.ToDouble(txt_qty.Text);

            //u_stock1 = old_stock1 + new_stock1;
            //string[] row2 = { txt_stock.Text, u_stock1.ToString() };
            //hidden_table1.Rows.Add(row2);

            double d;
            double g = Convert.ToDouble(txt_total.Text);
            double f = Convert.ToDouble(txt_unitprice.Text);
            d = g + f;

            double a;
            double b = Convert.ToDouble(textBox1.Text);
            double c = Convert.ToDouble(txt_qty.Text);
            a = b + c;

            string[] row = { txt_item_code.Text, txt_unitprice.Text, txt_size.Text, txt_qty.Text,a.ToString(), d.ToString(), txt_ptotal.Text };
            stiitched_table.Rows.Add(row);

            Double sum = 0;
            for (int i = 0; i < stiitched_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(stiitched_table.Rows[i].Cells[6].Value);
            }
            label14.Text = (stiitched_table.RowCount).ToString();
            txt_grand_total.Text = sum.ToString("N2");

            Double sum1 = 0;
            for (int i = 0; i < stiitched_table.Rows.Count; ++i)
            {
                sum1 += Convert.ToDouble(stiitched_table.Rows[i].Cells[3].Value);
            }
            txt_totalqty.Text = sum1.ToString("N2");
            ////For Tax Amount Calculation with respect to 17% 
            //label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
            //label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

          //  txt_item_code.Clear();
            //txt_pname.Clear();
            // txt_pcat.Clear();
            // txt_stock.Clear();
            txt_unitprice.Clear();
            txt_qty.Clear();
            txt_ptotal.Clear();
            // txt_pdesc.Clear();
            //}
        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }

        private void txt_grand_total_TextChanged(object sender, EventArgs e)
        {
            double input1 = Convert.ToDouble(txt_tayloe_amount.Text);
            double input2 = Convert.ToDouble(txt_grand_total.Text);

            double result = input2 + input1;

            txt_total_bill.Text = result.ToString("0");
        }

        private void txt_totalqty_TextChanged(object sender, EventArgs e)
        {
            try
            {         
                Double A = Convert.ToDouble(txt_stock.Text);
                Double B = Convert.ToDouble(txt_totalqty.Text);

                Double C = Convert.ToDouble(txt_items.Text);

                txt_result.Text = (A + B).ToString("N2");
                txt_result1.Text = (C - B).ToString("N2");


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txt_size_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT ifnull(sum(quantity),0) FROM stitchedproduct WHERE size = '" + txt_size.Text + "' AND p_code ='" + txt_item_code.Text + "' AND t_name ='" + comb_cname.Text + "' ", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    textBox1.Text = dr.GetValue(0).ToString();
                    //txt_balan.Text = dr.GetValue(1).ToString();
                }
                con.Close();
            }
        }

        private void txt_price_TextChanged(object sender, EventArgs e)
        {
            double input1 = Convert.ToDouble(txt_per.Text);
            double input2 = Convert.ToDouble(txt_price.Text);

            double result = input2 * input1;

            txt_total.Text = result.ToString("0");
        }
    }
}
