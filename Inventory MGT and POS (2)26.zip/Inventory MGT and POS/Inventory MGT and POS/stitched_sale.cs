﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class stitched_sale : Form
    {
        //AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        //List<string> listOnit = new List<string>();
        private MySqlConnection con;
        public stitched_sale()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }
        private void p_code_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_code FROM stitchedproduct", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_item_code.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        private void product_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_name FROM stitchedproduct", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
         //   txt_pname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        private void size_search()
        {
            //MySqlCommand cmd = new MySqlCommand("SELECT size FROM stitchedproduct", con);
            //con.Open();
            //MySqlDataReader reader = cmd.ExecuteReader();
            //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            //while (reader.Read())
            //{
            //    MyCollection.Add(reader.GetString(0));
            //}
            //txt_size.AutoCompleteCustomSource = MyCollection;
            //con.Close();
        }
        private void txt_pname_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    MySqlCommand cmd = new MySqlCommand("SELECT p_code,type,category FROM stitchedproduct WHERE p_name = '" + txt_pname.Text + "'", con);
            //    con.Open();
            //    MySqlDataReader dr = cmd.ExecuteReader();
            //    while (dr.Read())
            //    {
            //        txt_item_code.Text = dr.GetValue(0).ToString();
            //       txt_type.Text = dr.GetValue(1).ToString();
            //       txt_pcat.Text = dr.GetValue(2).ToString();


            //    }
            //    con.Close();
            //}
        }
        public void tailor_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT t_name FROM stitchedproduct", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_taylor.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void stitched_sale_Load(object sender, EventArgs e)
        {
            tailor_name_search();
            label5.Text = Login.u_name;
            size_search();
            product_name_search();
            max_invoice_id();
            customer_name_search();
            p_code_search();
        }
        private void max_invoice_id()
        {
            //using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(invoice_num)+1 FROM stitchedsale ", con))
            //{
            //    cmd.CommandType = CommandType.Text;
            //    con.Open();
            //    txt_invoice.Text = cmd.ExecuteScalar().ToString();
            //    con.Close();
            //}
        }
        public void customer_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT c_name FROM customer", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            comb_cname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void txt_size_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    MySqlCommand cmd = new MySqlCommand("SELECT quantity,unit_price FROM stitchedproduct WHERE size = '" + txt_size.Text + "' AND p_name ='" + txt_pname.Text + "' AND p_code = '" + txt_item_code.Text + "' ORDER BY COUNT(DISTINCT stitched_id) ", con);
            //    con.Open();
            //    MySqlDataReader dr = cmd.ExecuteReader();
            //    while (dr.Read())
            //    {
            //        txt_stock.Text = dr.GetValue(0).ToString();
            //        txt_unitprice.Text = dr.GetValue(1).ToString();


            //    }
            //    con.Close();
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                for (int i = 0; i < TableProducts.Rows.Count; i++)
                {
                    using (MySqlCommand cmd = new MySqlCommand("INSERT INTO stitchedsale(p_code,date,p_name,c_id,c_name,category,sub_name,per_gaj,items,quantity,unit_price,total,total_items,grand_total,cash_paid,change_cash) values(@code,Now(),@pname,@cid,@cname,@category,@sub_name,@per_gaj,@items,@qty,@unit_price,@total,@total_items,@grand_total,@cash_paid,@change)", con))
                    {
                        //  cmd.Parameters.AddWithValue("@code", txt_code.Text);
                       // cmd.Parameters.AddWithValue("@date", txt_issued.Value);
                        cmd.Parameters.AddWithValue("@cname", comb_cname.Text);
                        cmd.Parameters.AddWithValue("@cid", Convert.ToInt64(txt_id.Text));

                        cmd.Parameters.AddWithValue("@category", txt_cat.Text);
                        // cmd.Parameters.AddWithValue("@tphone", txt_phone.Text);
                        // cmd.Parameters.AddWithValue("@purchase_price", txt_purchase.Text);
                        cmd.Parameters.AddWithValue("@code", TableProducts.Rows[i].Cells[0].Value.ToString());
                        cmd.Parameters.AddWithValue("@pname", TableProducts.Rows[i].Cells[1].Value.ToString());
                        cmd.Parameters.AddWithValue("@sub_name", TableProducts.Rows[i].Cells[2].Value.ToString());
                        cmd.Parameters.AddWithValue("@per_gaj", TableProducts.Rows[i].Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@items", Convert.ToDouble(TableProducts.Rows[i].Cells[4].Value));

                        cmd.Parameters.AddWithValue("@qty", Convert.ToDouble(TableProducts.Rows[i].Cells[6].Value));
                        cmd.Parameters.AddWithValue("@unit_price", Convert.ToInt32(TableProducts.Rows[i].Cells[5].Value));
                        //cmd.Parameters.AddWithValue("@purchase_price", Convert.ToInt32(stiitched_table.Rows[i].Cells[6].Value));
                        cmd.Parameters.AddWithValue("@total", Convert.ToDouble(TableProducts.Rows[i].Cells[7].Value));
                        cmd.Parameters.AddWithValue("@total_items", Convert.ToInt32(label7.Text));

                        //  cmd.Parameters.AddWithValue("@Updatedstock", Convert.ToDouble(Table_purchase.Rows[i].Cells[6].Value));

                        // cmd.Parameters.AddWithValue("@subtotal", Convert.ToDouble(label9.Text));
                        //cmd.Parameters.AddWithValue("@taxamount", Convert.ToDouble(label11.Text));
                        cmd.Parameters.AddWithValue("@grand_total", Convert.ToDouble(txt_grand_total.Text));
                        cmd.Parameters.AddWithValue("@cash_paid", Convert.ToDouble(txt_cash_rec.Text));
                        cmd.Parameters.AddWithValue("@change", Convert.ToDouble(txt_change.Text));
                        //  cmd.Parameters.AddWithValue("@cashier", label5.Text.ToString());

                        cmd.ExecuteNonQuery();
                        // con.Close();
                        //2 cmd.Dispose();
                    }
                }
                for (int i = 0; i < TableProducts.Rows.Count; i++)
                {

                    string query = ("UPDATE stitchedproduct SET updated_stock ='" + hidden_table.Rows[i].Cells[1].Value + "' WHERE p_code = '" + TableProducts.Rows[i].Cells[0].Value + "'ORDER BY stitched_id DESC limit 1 ;");
                    MySqlCommand cmnd = new MySqlCommand(query, con);
                    MySqlDataReader read;

                    read = cmnd.ExecuteReader();
                    // 
                    read.Close();
                    cmnd.Dispose();
                }
                using (MySqlCommand cmd1 = new MySqlCommand("INSERT INTO customer_ledger(c_id,cus_name,date,cus_credit,cus_debit,cus_balance,description)values(@cid,@cusname,NOW(),@cuscredit,@cusdebit,@cusbalance,@description)", con))
                {
                    cmd1.Parameters.AddWithValue("@cid", Convert.ToInt64(txt_id.Text));

                    cmd1.Parameters.AddWithValue("@cusname", comb_cname.Text);
                    cmd1.Parameters.AddWithValue("@cuscredit", Convert.ToDouble(txt_grand_total.Text));
                    cmd1.Parameters.AddWithValue("@cusdebit", Convert.ToDouble(txt_cash_rec.Text));
                    cmd1.Parameters.AddWithValue("@cusbalance", txt_bal.Text);
                    cmd1.Parameters.AddWithValue("@description", "Sale Against Invoice Number:" + txt_invoice.Text);

                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();
                }
                double a = Convert.ToDouble(txt_change.Text);

                if (a < 0)
                {
                    double b = Convert.ToDouble(txt_bal.Text);
                    // double c = b - a;
                    string query = ("UPDATE customer SET c_rmnblnc ='" + b.ToString() + "' WHERE c_id  = '" + txt_id.Text + "' ;");
                    MySqlCommand cmnd1 = new MySqlCommand(query, con);
                    MySqlDataReader read1;
                    // MessageBox.Show("test");
                    read1 = cmnd1.ExecuteReader();
                    read1.Close();
                    cmnd1.Dispose();
                }
                //for (int i = 0; i < TableProducts.Rows.Count; i++)
                //{

                //    string query = ("UPDATE stitchedproduct set quantity ='" + dataGridView1.Rows[i].Cells[1].Value + "' WHERE p_code = '" + TableProducts.Rows[i].Cells[0].Value + "' ;");
                //    MySqlCommand cmnd = new MySqlCommand(query, con);
                //    MySqlDataReader read;

                //    read = cmnd.ExecuteReader();
                //    // 
                //    read.Close();
                //    cmnd.Dispose();
                //}

                con.Close();
                MessageBox.Show("Success");

                comb_cname.ResetText();
                //txt_phone.Clear();
                //txt_id.Clear();
                txt_product.Clear();
                // txt_purchase.Clear();

                TableProducts.Rows.Clear();
                TableProducts.Refresh();


                txt_grand_total.Text = "0";
                txt_grand_total.Refresh();
                //txt_cash_rec.Clear();
                //txt_change.Clear();
                txt_cash_rec.Text = "0";
                //txt_change.Clear();
                txt_bal.Text = "0";
                txt_change.Text = "0";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }
        private void emptycart()
        {
            txt_id.Clear();
            comb_cname.ResetText();
            txt_grand_total.Clear();
            txt_grand_total.Refresh();
            txt_cash_rec.Clear();
            txt_change.Clear();

            TableProducts.Rows.Clear();
            TableProducts.Refresh();
            txt_invoice.Refresh();

            hidden_table.Rows.Clear();
            hidden_table.Refresh();
        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_qty.Text.Trim() != string.Empty)
                {
                    Double A = Convert.ToDouble(txt_unitprice.Text);
                    Double B = Convert.ToDouble(txt_qty.Text);
                    txt_ptotal.Text = (A * B).ToString("N2");
                }
                else if (txt_qty.Text.Trim() == string.Empty)
                {
                    txt_ptotal.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txt_qty_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    int u_stock;
            //    int old_stock = Convert.ToInt32(txt_stock.Text);
            //    int new_stock = Convert.ToInt32(txt_qty.Text);

            //    u_stock = old_stock - new_stock;
            //    string[] row1 = { txt_stock.Text, u_stock.ToString() };
            //    hidden_table.Rows.Add(row1);

            //    string[] row = { txt_item_code.Text, txt_pname.Text, txt_type.Text, txt_pcat.Text, txt_size.Text, txt_qty.Text, txt_unitprice.Text, txt_ptotal.Text };
            //    TableProducts.Rows.Add(row);

            //    Double sum = 0;
            //    for (int i = 0; i < TableProducts.Rows.Count; ++i)
            //    {
            //        sum += Convert.ToDouble(TableProducts.Rows[i].Cells[7].Value);
            //    }
            //    label7.Text = (TableProducts.RowCount).ToString();
            //    txt_grand_total.Text = sum.ToString("N2");
            //    //For Tax Amount Calculation with respect to 17% 
            //    //label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
            //    // label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

            //    txt_item_code.Clear();
            //    txt_pname.Clear();
            //    txt_type.Clear();
            //    txt_pcat.Clear();
            //    txt_size.Clear();
            //    txt_stock.Clear();
            //    txt_unitprice.Clear();
            //    txt_qty.Clear();
            //    txt_ptotal.Clear();
            //    // txt_pdesc.Clear();
            //}
        }

        private void comb_cname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT c_id,c_rmnblnc FROM customer WHERE c_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_id.Text = dr.GetValue(0).ToString();
                    txt_cbalance.Text = dr.GetValue(1).ToString();
                    //txt_phone.Text = dr.GetValue(2).ToString();
                }
                con.Close();
            }
        }

        private void txt_grand_total_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_cash_rec_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_change.Text = (Convert.ToDouble(txt_cash_rec.Text) - Convert.ToDouble(txt_grand_total.Text)).ToString("N2");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (Application.OpenForms.OfType<add_customer>().Any())
            //{
            //    Application.OpenForms.OfType<add_customer>().First().BringToFront();
            //}
            //else
            //{
            //    var dash = new add_customer();
            //    dash.Show();

            //}
        }

        private void txt_item_code_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    MySqlCommand cmd = new MySqlCommand("SELECT p_name,type,category,size,quantity,unit_price FROM stitchedproduct WHERE p_code = '" + txt_item_code.Text + "'", con);
            //    con.Open();
            //    MySqlDataReader dr = cmd.ExecuteReader();
            //    while (dr.Read())
            //    {
            //        txt_pname.Text = dr.GetValue(0).ToString();
            //        txt_type.Text = dr.GetValue(1).ToString();
            //        txt_pcat.Text = dr.GetValue(2).ToString();

            //        txt_size.Text = dr.GetValue(3).ToString();
            //        txt_stock.Text = dr.GetValue(4).ToString();
            //        txt_unitprice.Text = dr.GetValue(5).ToString();


            //    }
            //    con.Close();
            //}
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products WHERE supplier_name = '" + txt_pcat.Text + "'", con);
                // con.Open();

                MySqlCommand cmd1 = new MySqlCommand("SELECT p_code,t_id FROM stitchedproduct WHERE t_name = '" + txt_taylor.Text + "'", con);
                con.Open();
                MySqlDataReader reader = cmd1.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                    txt_tid.Text = reader.GetValue(1).ToString();
                }
                txt_item_code.AutoCompleteCustomSource = MyCollection;
                //con.Close();

                con.Close();
            }
        }

        private void txt_item_code_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_name,sub_name,per_gaj,updated_stock FROM stitchedproduct WHERE p_code = '" + txt_item_code.Text + "' AND t_name ='" + txt_taylor.Text + "'", con); //ORDER BY COUNT(DISTINCT p_id )
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_product.Text = dr.GetValue(0).ToString();
                    txt_sub_product.Text = dr.GetValue(1).ToString();
                    txt_per.Text = dr.GetValue(2).ToString();
                    txt_items.Text = dr.GetValue(3).ToString();
                   // txt_suit.Text = dr.GetValue(4).ToString();
                    // txt_unitprice.Text = dr.GetValue(3).ToString();
                }
                con.Close();
            }
        }

        private void txt_qty_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (txt_qty.Text.Trim() != string.Empty)
                {
                    Double A = Convert.ToDouble(txt_unitprice.Text);
                    Double B = Convert.ToDouble(txt_qty.Text);
                    txt_ptotal.Text = (A * B).ToString("N2");
                }
                else if (txt_qty.Text.Trim() == string.Empty)
                {
                    txt_ptotal.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            double u_stock;
            double old_stock = Convert.ToDouble(txt_items.Text);
            double new_stock = Convert.ToDouble(txt_qty.Text);

            u_stock = old_stock - new_stock;
            string[] row1 = { txt_items.Text, u_stock.ToString() };
            hidden_table.Rows.Add(row1);

            

            string[] row = { txt_item_code.Text, txt_product.Text, txt_sub_product.Text, txt_per.Text, txt_items.Text, txt_unitprice.Text, txt_qty.Text, txt_ptotal.Text };
            TableProducts.Rows.Add(row);

            Double sum = 0;
            for (int i = 0; i < TableProducts.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(TableProducts.Rows[i].Cells[7].Value);
            }
            label7.Text = (TableProducts.RowCount).ToString();
            txt_grand_total.Text = sum.ToString("N2");
            ////For Tax Amount Calculation with respect to 17% 
            //label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
            //label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

            txt_item_code.Clear();
            //txt_pname.Clear();
            // txt_pcat.Clear();
            // txt_stock.Clear();
            txt_unitprice.Clear();
            txt_qty.Clear();
            txt_ptotal.Clear();
            // txt_pdesc.Clear();
            //}
        }

        private void txt_change_TextChanged(object sender, EventArgs e)
        {
            try
            {

                if ((Convert.ToDouble(txt_change.Text) < 0)) //&& (String.IsNullOrWhiteSpace(txt_change.Text))
                {
                    double a = -1;
                    double b = Convert.ToDouble(txt_change.Text);
                    double c = a * b;
                    double d = Convert.ToDouble(txt_cbalance.Text);
                    double f = c + d;
                    txt_bal.Text = f.ToString();
                }

                if (Convert.ToDouble(txt_cash_rec.Text) == Convert.ToDouble(txt_grand_total.Text))
                {
                    txt_bal.Text = txt_cbalance.Text.ToString();
                    //MessageBox.Show("err");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                con.Close();
            }
        }

        private void textBox1_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT SUM(quantity) FROM stitchedproduct WHERE size = '" + textBox1.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    textBox2.Text = dr.GetValue(0).ToString();
                    //txt_balan.Text = dr.GetValue(1).ToString();
                }
                con.Close();
            }
        }
    }
}
