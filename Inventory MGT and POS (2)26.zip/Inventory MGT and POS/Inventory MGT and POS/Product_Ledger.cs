﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Product_Ledger : Form
    {
        private MySqlConnection con;
        public Product_Ledger()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }
        public void get_No_of_Quotation()
        {
            DataTable dt = new DataTable();

            MySqlCommand cmd = new MySqlCommand("CALL `LOAD_PRODUCT_LEDGER`()", con);

            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();



            Product_table.DataSource = dt;


            Product_table.Columns[0].HeaderText = "Code";
            Product_table.Columns[1].HeaderText = "Product Name";
            Product_table.Columns[2].HeaderText = "Product QTY";


            Product_table.Columns[0].Width = 338;
            Product_table.Columns[1].Width = 338;
            Product_table.Columns[2].Width = 338;




        }

        private void Product_Ledger_Load(object sender, EventArgs e)
        {
            get_No_of_Quotation();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                MySqlDataAdapter sda = new MySqlDataAdapter("SELECT p_code,p_name,sum(p_qty) FROM sales WHERE s_date BETWEEN '" + dt_1.Text + "' AND '" + dt_2.Text + "' GROUP BY p_code", con);

                DataTable ds = new DataTable();
                sda.Fill(ds);

                Product_table.DataSource = ds;
                Product_table.Columns[0].HeaderText = "Code";
                Product_table.Columns[1].HeaderText = "Product Name";
                Product_table.Columns[2].HeaderText = "Product QTY";

                Product_table.Columns[0].Width = 338;
                Product_table.Columns[1].Width = 338;
                Product_table.Columns[2].Width = 338;

                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }


        }
    }
}
