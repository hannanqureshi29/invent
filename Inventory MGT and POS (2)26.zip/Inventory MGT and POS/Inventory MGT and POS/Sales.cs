﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Globalization;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Sales : Form
    {
        DataTable dta;
        private MySqlConnection con;
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        MySqlCommand cmd;
        public Sales()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void Sales_Load(object sender, EventArgs e)
        {
            load_sales();
            //  search_from_customer();
        }

        public void load_sales()
        {
           
            MySqlCommand cmd = new MySqlCommand("SELECT DISTINCT invoice_num,s_date,c_id,c_name,total_items,grand_total,cashier_name FROM sales ORDER BY invoice_num ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                sales_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            sales_table.DataSource = dta;
            sales_table.Columns[0].HeaderText = "Invoice #";
            sales_table.Columns[1].HeaderText = "Date";
            sales_table.Columns[2].HeaderText = "C ID";
            sales_table.Columns[3].HeaderText = "Customer Name";
            sales_table.Columns[4].HeaderText = "Total Items";
            sales_table.Columns[5].HeaderText = "Grand Total";
            sales_table.Columns[6].HeaderText = "Cashier Name";

            sales_table.Columns[0].Width = 40;
            sales_table.Columns[1].Width = 90;
            sales_table.Columns[2].Width = 40;
            sales_table.Columns[3].Width = 120;
            sales_table.Columns[4].Width = 50;
            sales_table.Columns[5].Width = 150;
            sales_table.Columns[6].Width = 100;

            sales_table.Columns[5].DefaultCellStyle.Format = "N2";
        }

        private void search_sales()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT DISTINCT invoice_num,s_date,c_id,c_name,total_items,grand_total,cashier_name FROM sales WHERE invoice_num like '" + txt_search.Text + "%' OR c_name like '" + txt_search.Text + "%' OR cashier_name like '" + txt_search.Text + "%' ORDER BY invoice_num ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "sales");
            //sales_table.DataSource = ds.Tables["sales"];
            //sales_table.Columns[0].HeaderText = "Invoice #";
            //sales_table.Columns[1].HeaderText = "Date";
            //sales_table.Columns[2].HeaderText = "C ID";
            //sales_table.Columns[3].HeaderText = "Customer Name";
            //sales_table.Columns[4].HeaderText = "Total Items";
            //sales_table.Columns[5].HeaderText = "Grand Total";
            //sales_table.Columns[6].HeaderText = "Cashier Name";

            //sales_table.Columns[0].Width = 40;
            //sales_table.Columns[1].Width = 90;
            //sales_table.Columns[2].Width = 40;
            //sales_table.Columns[3].Width = 120;
            //sales_table.Columns[4].Width = 50;
            //sales_table.Columns[5].Width = 150;
            //sales_table.Columns[6].Width = 100;

            //sales_table.Columns[5].DefaultCellStyle.Format = "N2";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //if (txt_search.Text == "")
            //{
            //    load_sales();
            //}
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            //}
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search Sales Record";
                // load_sales();

            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search Sales Record")
            {
                txt_search.Text = "";
            }
        }

        private void txt_search_KeyDown(object sender, KeyEventArgs e)
        {
            //search_sales();
        }


        private void sales_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            preview_sale edt = new preview_sale();
            int row = sales_table.CurrentRow.Index;

            edt.lbl_invoice_num.Text = Convert.ToString(sales_table[0, row].Value);
            edt.txt_cid.Text = Convert.ToString(sales_table[2, row].Value);
            // edt.txt_cbalance.Text = Convert.ToString(sales_table[2, row].Value);
            //edt.txt_Rev_Sta.Text = Convert.ToString(TableProducts[3, row].Value);
            edt.Show();
        }

        private void txt_search_KeyUp(object sender, KeyEventArgs e)
        {

            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("invoice_num LIKE '%" + txt_search.Text.ToString() + "%' OR c_name LIKE '%" + txt_search.Text.ToString() + "%' OR cashier_name LIKE '%" + txt_search.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            sales_table.DataSource = dv;
        }
    }
}
