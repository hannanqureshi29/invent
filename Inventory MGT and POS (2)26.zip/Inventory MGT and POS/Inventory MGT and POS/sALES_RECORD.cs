﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class sALES_RECORD : Form
    {
        DataTable dta;
        private MySqlConnection con;
        public sALES_RECORD()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void sALES_RECORD_Load(object sender, EventArgs e)
        {
            load_sales();
        }
        public void load_sales()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT DISTINCT invoice_num,s_date,grand_total FROM sales ORDER BY invoice_num ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                sales_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            sales_table.DataSource = dta;
            sales_table.Columns[0].HeaderText = "Invoice #";
            sales_table.Columns[1].HeaderText = "Date";
            
            sales_table.Columns[2].HeaderText = "Grand Total";
           

            sales_table.Columns[0].Width = 300;
            sales_table.Columns[1].Width = 300;
            
            
            sales_table.Columns[2].Width = 400;
            

            sales_table.Columns[2].DefaultCellStyle.Format = "N2";

            Double sum = 0;
            for (int i = 0; i < sales_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(sales_table.Rows[i].Cells[2].Value);
            }
            txt_sales.Text = sum.ToString("N2");


        }

        private void sales_table_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //foreach (DataGridViewRow row in sales_table.Rows)
            //{
            //    try
            //    {
            //        Double sum = 0;
            //        for (int i = 0; i < sales_table.Rows.Count; ++i)
            //        {
            //            sum += Convert.ToDouble(sales_table.Rows[i].Cells[2].Value);
            //        }
            //        txt_sales.Text = sum.ToString("N2");

            //    }
            //    catch (Exception exc)
            //    {
            //        // con.Close();
            //        MessageBox.Show(exc.ToString());
            //    }
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            //MySqlDataAdapter sda = new MySqlDataAdapter("SELECT COUNT(DISTINCT quotations.q_num),COUNT(DISTINCT orders.q_num),customer.company_name FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id INNER JOIN orders ON quotations.c_id = orders.c_id WHERE (orders.q_issued_at BETWEEN '" + dateTimePicker1.Text + "' AND '" + dateTimePicker2.Text + "') ", con);
            MySqlDataAdapter sda = new MySqlDataAdapter("SELECT DISTINCT invoice_num,s_date,grand_total FROM sales WHERE s_date >= '" + dateTimePicker1.Text + "' AND s_date <= '" + dateTimePicker2.Text + "' ORDER BY invoice_num ASC", con);
            //DataSet ds = new DataSet();
            DataTable ds = new DataTable();
            // sda.Fill(ds, "quotations");
            sda.Fill(ds);
            sales_table.DataSource = ds;
            sales_table.Columns[0].HeaderText = "Invoice #";
            sales_table.Columns[1].HeaderText = "Date";

            sales_table.Columns[2].HeaderText = "Grand Total";


            sales_table.Columns[0].Width = 300;
            sales_table.Columns[1].Width = 300;


            sales_table.Columns[2].Width = 400;

            con.Close();
            Double sum = 0;
            for (int i = 0; i < sales_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(sales_table.Rows[i].Cells[2].Value);
            }
            txt_sales.Text = sum.ToString("N2");
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void sales_table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }
    }
}
