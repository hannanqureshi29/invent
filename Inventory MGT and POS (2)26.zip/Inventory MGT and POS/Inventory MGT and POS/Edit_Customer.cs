﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Edit_Customer : Form
    {
        private MySqlConnection con;
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        MySqlCommand cmd;
        private Dash dash;
        private readonly Customers customer_form;

        public object MessageBoxButton { get; private set; }

        public Edit_Customer(Customers crt)
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            customer_form = crt;
        }

        public Edit_Customer(Dash dash)
        {
            this.dash = dash;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Edit_Customer_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = new MySqlCommand("UPDATE customer SET c_name='" + txt_name.Text + "',c_phone='" + txt_phone.Text + "',c_email='" + txt_email.Text + "',c_adress='" + txt_adress.Text + "',c_opnblnc='" + txt_opnblnc.Text + "',c_rmnblnc='" + txt_rmnblnc.Text + "' WHERE c_id='" + txt_id.Text + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                customer_form.load_customers();
                //customer_form.customer_table.Refresh();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Customers master = (Customers)Application.OpenForms["Customers"];
            master.load_customers();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = new MySqlCommand("DELETE FROM customer WHERE c_id = '" + txt_id.Text + "'  ", con);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record has been Deleted");
                con.Close();
                // clear_data();
                //insert_data();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not Deleetd" + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
    }
}
