﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Products : Form
    {
        private MySqlConnection con;
        //  SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        MySqlCommand cmd;
        public Products()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            //if (textBox1.Text == "Search Products")
            //{
            //    textBox1.Text = "";
            //    textBox1.ForeColor = Color.Black;
            //}
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    textBox1.Text = "Search Products";
            //    textBox1.ForeColor = Color.DimGray;
            //}                
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            //txt_name.Text = "";
            //txt_name.ForeColor = Color.Black;
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_name.Text = "Product Name";
            //    txt_name.ForeColor = Color.DimGray;
            //}
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // open file dialog   
            //OpenFileDialog open = new OpenFileDialog();
            //// image filters  
            //open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            //if (open.ShowDialog() == DialogResult.OK)
            //{
            //    // display image in picture box  
            //    pictureBox1.BackgroundImage = new Bitmap(open.FileName);               
            //    // image file path  
            //    txt_path.Text = open.FileName;
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                for (int i = 0; i < Product_table.Rows.Count; i++)
                {
                    using (MySqlCommand cmd = new MySqlCommand("INSERT INTO products(p_name,p_desc,p_cat,p_code,meter,total_gaj,per_gaj,p_purchase_price,invo_num,supplier_name,total,grand_gaj) values(@name,@desc,@cat,@code,@meter,@totalgaj,@pergaj,@p_price,@invonum,@suppliername,@total,@grandgaj)", con))
                    {
                        cmd.Parameters.AddWithValue("@invonum", txt_invoice.Text);
                        // (@name, @desc, @cat, @code, @meter, @totalgaj, @pergaj, @p_price, @suppliername)
                        cmd.Parameters.AddWithValue("@name", Product_table.Rows[i].Cells[0].Value.ToString());
                        cmd.Parameters.AddWithValue("@cat", txt_cat.Text);
                        cmd.Parameters.AddWithValue("@code", Product_table.Rows[i].Cells[1].Value.ToString());
                        cmd.Parameters.AddWithValue("@desc", Product_table.Rows[i].Cells[2].Value.ToString());

                        cmd.Parameters.AddWithValue("@meter", Convert.ToDouble(Product_table.Rows[i].Cells[3].Value));
                        cmd.Parameters.AddWithValue("@totalgaj", Convert.ToDouble(Product_table.Rows[i].Cells[4].Value));
                        cmd.Parameters.AddWithValue("@pergaj", Convert.ToDouble(Product_table.Rows[i].Cells[5].Value));
                        cmd.Parameters.AddWithValue("@p_price", Convert.ToDouble(Product_table.Rows[i].Cells[6].Value));
                        cmd.Parameters.AddWithValue("@suppliername", Product_table.Rows[i].Cells[7].Value);
                        cmd.Parameters.AddWithValue("@total", Convert.ToDouble(txt_grand_total.Text));
                        cmd.Parameters.AddWithValue("@grandgaj", Convert.ToDouble(txt_totalgaj.Text));


                        //cmd.Parameters.AddWithValue("@grand_total", Convert.ToDouble(txt_grand_total.Text));grand_gaj
                        //cmd.Parameters.AddWithValue("@cash_paid", Convert.ToDouble(txt_cash_rec.Text));
                        //cmd.Parameters.AddWithValue("@change", Convert.ToDouble(txt_change.Text));


                        cmd.ExecuteNonQuery();
                        // con.Close();
                        //2 cmd.Dispose();
                    }
                }
                using (MySqlCommand cmd1 = new MySqlCommand("INSERT INTO supplier_ledger(sp_id,sup_name,date,sup_credit,sup_debit,sup_balance)values(@spid,@supname,NOW(),@supcredit,@supdebit,@supbalance)", con))
                {
                    cmd1.Parameters.AddWithValue("@spid", Convert.ToInt64(txt_idsup.Text));

                    cmd1.Parameters.AddWithValue("@supname", txt_supplier.Text);
                    cmd1.Parameters.AddWithValue("@supcredit", 0);
                    cmd1.Parameters.AddWithValue("@supdebit", Convert.ToDouble(txt_grand_total.Text));
                    cmd1.Parameters.AddWithValue("@supbalance", txt_total_bill.Text);
                    //cmd1.Parameters.AddWithValue("@description", "Sale Against Invoice Number:" + txt_invoice.Text);

                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();
                }

                string query = ("UPDATE suppliers SET sp_rmnblnc ='" + txt_total_bill.Text + "' WHERE sp_id = '" + txt_idsup.Text + "' ;");
                MySqlCommand cmnd1 = new MySqlCommand(query, con);
                MySqlDataReader read1;
                // MessageBox.Show("test");
                read1 = cmnd1.ExecuteReader();
                read1.Close();
                cmnd1.Dispose();


                con.Close();
                MessageBox.Show("Success");

                max_invoice_id();

                Product_table.Rows.Clear();
                Product_table.Refresh();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
           
        }
        private void max_invoice_id()
        {
            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(invo_num)+1 FROM products ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txt_invoice.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }

        private void Products_Load(object sender, EventArgs e)
        {
            max_invoice_id();
            //load_products();
            supplier_name_search();
            Product_table.Columns[0].Width = 60;
            Product_table.Columns[1].Width = 60;
            Product_table.Columns[2].Width = 40;
            Product_table.Columns[3].Width = 100;
            Product_table.Columns[4].Width = 60;
            Product_table.Columns[5].Width = 100;
            Product_table.Columns[6].Width = 60;
            Product_table.Columns[7].Width = 100;
           // Product_table.Columns[8].Width = 60;

        }


        private void txt_cat_Enter(object sender, EventArgs e)
        {
            //txt_cat.Text = "";
            //txt_cat.ForeColor = Color.Black;
        }

        private void txt_cat_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_cat.Text = "Product Category";
            //    txt_cat.ForeColor = Color.DimGray;
            //}
        }

        private void txt_desc_Enter(object sender, EventArgs e)
        {
            //txt_desc.Text = "";
            //txt_desc.ForeColor = Color.Black;
        }

        private void txt_desc_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_desc.Text = "Product Description";
            //    txt_desc.ForeColor = Color.DimGray;
            //}
        }

        private void txt_code_Enter(object sender, EventArgs e)
        {
            //txt_code.Text = "";
            //txt_code.ForeColor = Color.Black;
        }

        private void txt_code_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_code.Text = "Assign Product Code";
            //    txt_code.ForeColor = Color.DimGray;
            //}
        }

        private void txt_purchase_price_Enter(object sender, EventArgs e)
        {
            //txt_purchase_price.Text = "";
            //txt_purchase_price.ForeColor = Color.Black;
        }

        private void txt_purchase_price_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_purchase_price.Text = "Purchasing Price";
            //    txt_purchase_price.ForeColor = Color.DimGray;
            //}
        }

        private void txt_sale_price_Enter(object sender, EventArgs e)
        {
            //txt_sale_price.Text = "";
            //txt_sale_price.ForeColor = Color.Black;
        }

        private void txt_sale_price_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_sale_price.Text = "Sales Price";
            //    txt_sale_price.ForeColor = Color.DimGray;
            //}
        }

        private void txt_stock_Enter(object sender, EventArgs e)
        {
            //txt_stock.Text = "";
            //txt_stock.ForeColor = Color.Black;
        }

        private void txt_stock_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_stock.Text = "Stock";
            //    txt_stock.ForeColor = Color.DimGray;
            //}
        }

        private void txt_supplier_Enter(object sender, EventArgs e)
        {
            //txt_supplier.Text = "";
            //txt_supplier.ForeColor = Color.Black;
        }

        private void txt_supplier_Leave(object sender, EventArgs e)
        {
            //if (String.IsNullOrEmpty(textBox1.Text))
            //{
            //    txt_supplier.Text = "Supplier Name";
            //    txt_supplier.ForeColor = Color.DimGray;
            //}
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void txt_supplier_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT sp_id,sp_rmnblnc FROM suppliers WHERE sp_name = '" + txt_supplier.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                     txt_idsup.Text = dr.GetValue(0).ToString();
                    txt_balan.Text = dr.GetValue(1).ToString();
                }
                con.Close();
            }
        }
        public void supplier_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT sp_name FROM suppliers", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_supplier.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {


            //if (e.KeyCode == Keys.Enter)
            //{
            //    double input1 = Convert.ToDouble(txt_meter.Text);
            //    double input2 = Convert.ToDouble(textBox3.Text);

            //    double result = input1 + input2;


            //    textBox4.Text = result.ToString("0.0");
            //    txt_meter.Text = textBox3.Text;
            //}


        }

        private void txt_per_gaj_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                double input1 = Convert.ToDouble(txt_stock.Text);
                double input2 = Convert.ToDouble(txt_per_gaj.Text);

                double result = input1 * input2;

                txt_purchase_price.Text = result.ToString("0.0");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txt_gajrate_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_meter.Text) || string.IsNullOrEmpty(txt_purchase_price.Text))
            {
                MessageBox.Show("Please insert Meter and Purchase Price ", "Error");
            }
            else
            {

                string[] row = { txt_name.Text, txt_code.Text, txt_desc.Text, actual_met.Text, txt_stock.Text, txt_per_gaj.Text, txt_purchase_price.Text, txt_supplier.Text };
                Product_table.Rows.Add(row);
                Double sum = 0;
                Double sum1 = 0;
                for (int i = 0; i < Product_table.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(Product_table.Rows[i].Cells[6].Value);
                    sum1 += Convert.ToDouble(Product_table.Rows[i].Cells[4].Value);
                }
                txt_grand_total.Text = sum.ToString("N2");
                txt_totalgaj.Text = sum1.ToString("N2");

                // label14.Text = (stiitched_table.RowCount).ToString();

                txt_name.Clear();
                txt_code.Clear();
                txt_desc.Clear();
                txt_meter.Clear();
                actual_met.Clear();
                txt_stock.Clear();
                txt_per_gaj.Clear();
                txt_purchase_price.Clear();
               // txt_supplier.Clear();


            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            var dash = new product_list();
            dash.Show();
        }

        private void txt_grand_total_TextChanged(object sender, EventArgs e)
        {
            double input1 = Convert.ToDouble(txt_balan.Text);
            double input2 = Convert.ToDouble(txt_grand_total.Text);

            double result = input2 + input1;

            txt_total_bill.Text = result.ToString("0");
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           // if (e.KeyCode == Keys.Enter)
            //{
                //double input1 = Convert.ToDouble(txt_meter.Text);
                //double input2 = Convert.ToDouble(textBox4.Text);

                //double result = input1 + input2;

                //textBox5.Text = result.ToString("0.0");
           // }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_meter.Text))
            {
                MessageBox.Show("Please insert Meter", "Error");
            }
            else
            {
                string[] row = { txt_meter.Text };
                hidden_table.Rows.Add(row);


                Double sum = 0;

                for (int i = 0; i < hidden_table.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(hidden_table.Rows[i].Cells[0].Value);

                }
                actual_met.Text = sum.ToString("N2");
            }
            
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                double input1 = Convert.ToDouble(txt_gajrate.Text);
                double input2 = Convert.ToDouble(actual_met.Text);

                double result = input2 / input1;

                txt_stock.Text = result.ToString("0.0");
            }
        }
    }
}
