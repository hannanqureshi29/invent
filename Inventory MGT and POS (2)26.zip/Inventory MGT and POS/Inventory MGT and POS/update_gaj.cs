﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Inventory_MGT_and_POS
{
    public partial class update_gaj : Form
    {
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        List<string> listOnit = new List<string>();
        private MySqlConnection con;
        public update_gaj()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_qty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                double u_stock;
                double old_stock = Convert.ToDouble(txt_stock.Text);
                double new_stock = Convert.ToDouble(txt_qty.Text);

                u_stock = old_stock - new_stock;
                string[] row1 = { txt_stock.Text, u_stock.ToString() };
                hidden_table.Rows.Add(row1);

                string[] row = { txt_item_code.Text, txt_pname.Text, txt_qty.Text, u_stock.ToString() };
                Table_purchase.Rows.Add(row);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void update_gaj_Load(object sender, EventArgs e)
        {
            supplier_name_search();
        }
        public void supplier_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_pcat.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void txt_pcat_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products WHERE supplier_name = '" + txt_pcat.Text + "'", con);
                // con.Open();

                MySqlCommand cmd1 = new MySqlCommand("SELECT p_code FROM products WHERE supplier_name = '" + txt_pcat.Text + "' AND total_gaj > 0", con);
                con.Open();
                MySqlDataReader reader = cmd1.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txt_item_code.AutoCompleteCustomSource = MyCollection;
                //con.Close();

                con.Close();
            }
        }

        private void txt_item_code_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_name,total_gaj FROM products WHERE p_code = '" + txt_item_code.Text + "' AND supplier_name ='" + txt_pcat.Text + "' ", con); //ORDER BY COUNT(DISTINCT p_id )
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_pname.Text = dr.GetValue(0).ToString();
                    // txt_pcat.Text = dr.GetValue(1).ToString();
                    txt_stock.Text = dr.GetValue(1).ToString();
                   // txt_pdesc.Text = dr.GetValue(2).ToString();
                    // txt_unitprice.Text = dr.GetValue(3).ToString();
                }
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                for (int i = 0; i < Table_purchase.Rows.Count; i++)
                {

                    string query = ("UPDATE products set total_gaj ='" + Table_purchase.Rows[i].Cells[3].Value + "' WHERE p_code = '" + Table_purchase.Rows[i].Cells[0].Value + "' ;");
                    MySqlCommand cmnd = new MySqlCommand(query, con);
                    MySqlDataReader read;

                    read = cmnd.ExecuteReader();
                    //  con.Close();
                    //read.Close();
                }
                con.Close();
                MessageBox.Show("Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }
    }
}
