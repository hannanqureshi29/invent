﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Credit_book : Form
    {
        private MySqlConnection con;
        MySqlCommand cmd;
        public Credit_book()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new MySqlCommand("insert into credit_book(name,issued_date,cash,receiving_date,status) values(@name,@issueddate,@cash,@receivingdate,@status)", con);
            con.Open();
            cmd.Parameters.AddWithValue("@name", txt_name.Text);
            cmd.Parameters.AddWithValue("@issueddate", txt_issued.Text);
            cmd.Parameters.AddWithValue("@cash", txt_cash.Text);
            cmd.Parameters.AddWithValue("@receivingdate", txt_validity.Text);
            cmd.Parameters.AddWithValue("@status", combo_status.Text);

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");
            load_record();
        }
        private void load_record()
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT credit_id,name,issued_date,cash,receiving_date,status FROM credit_book ORDER BY credit_id ASC", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "credit_book");
            credit_record_table.DataSource = ds.Tables["credit_book"];

            credit_record_table.Columns[0].HeaderText = "ID";
            credit_record_table.Columns[1].HeaderText = "Name";
            credit_record_table.Columns[2].HeaderText = "Issued Date";
            credit_record_table.Columns[3].HeaderText = "Cash";
            credit_record_table.Columns[4].HeaderText = "Receiving Date";
            credit_record_table.Columns[5].HeaderText = "Status";

            credit_record_table.Columns[0].Width = 30;
            credit_record_table.Columns[1].Width = 50;
            credit_record_table.Columns[2].Width = 80;
            credit_record_table.Columns[3].Width = 80;
            credit_record_table.Columns[4].Width = 80;
            credit_record_table.Columns[5].Width = 80;

            credit_record_table.Columns[3].DefaultCellStyle.Format = "N2";


            credit_record_table.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;


            credit_record_table.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record_table.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }

        private void Credit_book_Load(object sender, EventArgs e)
        {
            txt_issued.Value = System.DateTime.Now;
            txt_validity.Value = System.DateTime.Now;
            load_record();
        }

        private void credit_record_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            update_creditbook fr = new update_creditbook();
            int row = credit_record_table.CurrentRow.Index;
            //    update_creditbook fr = new update_creditbook(this);
            //    int row = credit_record_table.CurrentRow.Index;
            // fr.Shown += (senderfr, efr) =>
            // {
            fr.txt_id.Text = Convert.ToString(credit_record_table[0, row].Value);
            fr.txt_name.Text = Convert.ToString(credit_record_table[1, row].Value);
            fr.txt_issued.Value = Convert.ToDateTime(credit_record_table[2, row].Value);

            fr.txt_cash.Text = Convert.ToString(credit_record_table[3, row].Value);
            fr.txt_validity.Value = Convert.ToDateTime(credit_record_table[4, row].Value);
            fr.combo_status.Text = Convert.ToString(credit_record_table[5, row].Value);
            // fr.txt_email.Text = Convert.ToString(customer_table[3, row].Value);

            // };
            fr.Show();
        }
    }
}
