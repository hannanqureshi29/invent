﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Customers : Form
    {
        DataTable dta;
        private MySqlConnection con;
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        MySqlCommand cmd;
        //  MySqlDataAdapter adapt;
        public Customers()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }
        public void search_customer()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT c_id,c_name,c_phone,c_email,c_adress,c_opnblnc,c_rmnblnc FROM customer WHERE c_name like '" + txt_search_customer.Text+ "%' OR c_phone like '" + txt_search_customer.Text + "%' OR c_email like '" + txt_search_customer.Text + "%' OR c_adress like '" + txt_search_customer.Text + "%' ORDER BY c_id ASC", con);
            // DataSet ds = new DataSet();
            // da.Fill(ds, "Customers");
            // customer_table.DataSource = ds.Tables["Customers"];
            // customer_table.Columns[0].HeaderText = "ID";
            // customer_table.Columns[1].HeaderText = "Name";
            // customer_table.Columns[2].HeaderText = "Phone";
            // customer_table.Columns[3].HeaderText = "Email";
            // customer_table.Columns[4].HeaderText = "Adress";
            // customer_table.Columns[5].HeaderText = "Opening Balanace";
            // customer_table.Columns[6].HeaderText = "Remaining Balance";

            // customer_table.Columns[0].Width = 40;
            // customer_table.Columns[1].Width = 100;
            // customer_table.Columns[2].Width = 110;
            // customer_table.Columns[3].Width = 90;
            // customer_table.Columns[4].Width = 200;
            // customer_table.Columns[5].Width = 80;
            // customer_table.Columns[6].Width = 80;

            // customer_table.Columns[5].DefaultCellStyle.Format = "N2";
            // customer_table.Columns[6].DefaultCellStyle.Format = "N2";
        }
        public void load_customers()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT c_id,c_name,c_phone,c_email,c_adress,c_opnblnc,c_rmnblnc FROM customer ORDER BY c_id ASC",con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "customers");
            //customer_table.DataSource = ds.Tables["customers"];

            MySqlCommand cmd = new MySqlCommand("SELECT c_id,c_name,c_phone,c_email,c_adress,c_opnblnc,c_rmnblnc FROM customer ORDER BY c_id ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                customer_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            customer_table.DataSource = dta;
            customer_table.Columns[0].HeaderText = "ID";
            customer_table.Columns[1].HeaderText = "Name";
            customer_table.Columns[2].HeaderText = "Phone";
            customer_table.Columns[3].HeaderText = "Email";
            customer_table.Columns[4].HeaderText = "Adress";
            customer_table.Columns[5].HeaderText = "Opening Balanace";
            customer_table.Columns[6].HeaderText = "Remaining Balance";

            customer_table.Columns[0].Width = 40;
            customer_table.Columns[1].Width = 100;
            customer_table.Columns[2].Width = 110;
            customer_table.Columns[3].Width = 90;
            customer_table.Columns[4].Width = 200;
            customer_table.Columns[5].Width = 80;
            customer_table.Columns[6].Width = 80;


            customer_table.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            customer_table.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            customer_table.Columns[5].DefaultCellStyle.Format = "N2";
            customer_table.Columns[6].DefaultCellStyle.Format = "N2";


            Double sum = 0;
            for (int i = 0; i < customer_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(customer_table.Rows[i].Cells[6].Value);
            }
            txt_total.Text = sum.ToString("N2");

        }
        private void Customers_Load(object sender, EventArgs e)
        {
            load_customers();
            //  search_from_customer();
        }

        private void TablaProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //private void search_from_customer()
        //{
        //    MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer ", con);
        //    //  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
        //    con.Open();
        //    MySqlDataReader reader = cmd.ExecuteReader();
        //    AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

        //    while (reader.Read())
        //    {
        //        collection.Add(reader.GetString(0));
        //        collection.Add(reader.GetString(1));
        //         collection.Add(reader.GetString(2));
        //        collection.Add(reader.GetString(3));
        //        collection.Add(reader.GetString(4));
        //    }
        //    txt_search_customer.AutoCompleteCustomSource = collection;
        //    con.Close();
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_name.Text != "" || txt_name.Text == "Customer Name")
                {
                    cmd = new MySqlCommand("insert into customer(c_name,c_phone,c_email,c_adress,c_opnblnc,c_rmnblnc) values(@name,@phone,@email,@adress,@opnblnc,@rmnblnc)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@name", txt_name.Text);
                    cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
                    cmd.Parameters.AddWithValue("@email", txt_email.Text);
                    cmd.Parameters.AddWithValue("@adress", txt_adress.Text);
                    cmd.Parameters.AddWithValue("@opnblnc", txt_opnblnc.Text);
                    cmd.Parameters.AddWithValue("@rmnblnc", txt_rmnblnc.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Inserted Successfully");
                    load_customers();
                }
                else
                {
                    MessageBox.Show("Please Enter Customer Name");
                }
                txt_name.Clear();
                txt_phone.Clear();
                txt_email.Clear();
                txt_adress.Clear();
                txt_opnblnc.Clear();
                txt_rmnblnc.Clear();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

        }

        private void customer_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Edit_Customer fr = new Edit_Customer(this);
            int row = customer_table.CurrentRow.Index;
            fr.Shown += (senderfr, efr) =>
            {
                fr.txt_id.Text = Convert.ToString(customer_table[0, row].Value);
                fr.txt_name.Text = Convert.ToString(customer_table[1, row].Value);
                fr.txt_phone.Text = Convert.ToString(customer_table[2, row].Value);
                fr.txt_email.Text = Convert.ToString(customer_table[3, row].Value);
                fr.txt_adress.Text = Convert.ToString(customer_table[4, row].Value);
                fr.txt_opnblnc.Text = Convert.ToString(customer_table[5, row].Value);
                fr.txt_rmnblnc.Text = Convert.ToString(customer_table[6, row].Value);
            };
            fr.Show();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {

            if (txt_search_customer.Text == "Search Customer")
            {
                txt_search_customer.Text = "";
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {

            if (txt_search_customer.Text == "")
            {
                txt_search_customer.Text = "Search Customer";
                //load_customers();

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            //if (txt_search_customer.Text == "")
            //{
            //    load_customers();
            //}
        }

        private void txt_opnblnc_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            // search_customer();

        }

        private void txt_search_customer_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("c_name LIKE '%" + txt_search_customer.Text.ToString() + "%' OR c_phone LIKE '%" + txt_search_customer.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            customer_table.DataSource = dv;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var dash = new customerledger();
            dash.Show();
        }
    }
}
