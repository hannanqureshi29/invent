﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class addnew_tailor : Form
    {
        DataTable dta;
        private MySqlConnection con;
        MySqlCommand cmd;
        public addnew_tailor()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_name.Text != "" || txt_name.Text == "Taylor Name")
                {
                    cmd = new MySqlCommand("insert into tailor(t_name,t_phone,t_email,t_adress,t_opnblnc,t_rmnblnc) values(@name,@phone,@email,@adress,@opnblnc,@rmnblnc)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@name", txt_name.Text);
                    cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
                    cmd.Parameters.AddWithValue("@email", txt_email.Text);
                    cmd.Parameters.AddWithValue("@adress", txt_adress.Text);
                    cmd.Parameters.AddWithValue("@opnblnc", txt_opnblnc.Text);
                    cmd.Parameters.AddWithValue("@rmnblnc", txt_rmnblnc.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Inserted Successfully");
                    //load_tailor();
                }
                else
                {
                    MessageBox.Show("Please Enter Tailor Name");
                }
                txt_name.Clear();
                txt_phone.Clear();
                txt_email.Clear();
                txt_adress.Clear();
                txt_opnblnc.Clear();
                txt_rmnblnc.Clear();

                if (Application.OpenForms.OfType<taylor_sale>().Any())
                {
                    taylor_sale master = (taylor_sale)Application.OpenForms["taylor_sale"];
                    master.tailor_name_search();
                }
                else
                {

                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
