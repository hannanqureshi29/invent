﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;


namespace Inventory_MGT_and_POS
{
    public partial class Dash : Form
    {
        DataTable dta;
        DataTable dta1;
        DataTable dta2;
        private MySqlConnection con;
        //SaveFileDialog savefiledialog1 = new SaveFileDialog();
       // public string filename;
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        MySqlCommand cmd;
        MySqlDataAdapter adapt;
        public Dash(Main main)
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        public Dash()
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void Dash_Load(object sender, EventArgs e)
        {
            //savefiledialog1.FileName = "";
          //  savefiledialog1.Filter = "SQL (*.SQL)|*.SQL";
            count_customers();
            count_employees();
            count_suppliers();
            count_products();
            count_sales();
            load_customers_receiveable();
            load_suppliers_payable();
            load_tailor_payable();
            //load_low_stock_product();
            //  search_from_customer();
        }

        public void load_customers_receiveable()
        {
            //    MySqlDataAdapter da = new MySqlDataAdapter("SELECT c_id,c_name,c_rmnblnc FROM customer WHERE c_rmnblnc > 0 ORDER BY c_id ASC", con);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds, "customer");
            //    customer_table.DataSource = ds.Tables["customer"];
            MySqlCommand cmd = new MySqlCommand("SELECT c_id,c_name,c_rmnblnc FROM customer WHERE c_rmnblnc > 0 ORDER BY c_id ASC", con);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                customer_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            customer_table.DataSource = dta;

            customer_table.Columns[0].HeaderText = "ID";
            customer_table.Columns[1].HeaderText = "Customer Name";
            customer_table.Columns[2].HeaderText = "Amount Receiveable";

            customer_table.Columns[0].Width = 50;
            //customer_table.Columns[1].Width = 100;

            customer_table.Columns[1].DefaultCellStyle.Format = "N2";

            Double sum = 0;
            for (int i = 0; i < customer_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(customer_table.Rows[i].Cells[2].Value);
            }
            txt_customer_rcv.Text = sum.ToString("N2");
        }
        public void load_suppliers_payable()
        {
            //    MySqlDataAdapter da = new MySqlDataAdapter("SELECT sp_id,sp_name,sp_rmnblnc FROM suppliers WHERE sp_rmnblnc > 0 ORDER BY sp_id ASC", con);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds, "suppliers");
            //    suppliers_table.DataSource = ds.Tables["suppliers"];
            MySqlCommand cmd = new MySqlCommand("SELECT sp_id,sp_name,sp_rmnblnc FROM suppliers WHERE sp_rmnblnc > 0 ORDER BY sp_id ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta1 = new DataTable();
                sda.Fill(dta1);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta1;
                suppliers_table.DataSource = bsource;
                sda.Update(dta1);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            suppliers_table.DataSource = dta1;

            suppliers_table.Columns[0].HeaderText = "ID";
            suppliers_table.Columns[1].HeaderText = "Supplier Name";
            suppliers_table.Columns[2].HeaderText = "Amount Payable";

            //customer_table.Columns[0].Width = 100;
            //customer_table.Columns[1].Width = 100;

            suppliers_table.Columns[1].DefaultCellStyle.Format = "N2";

            Double sum = 0;
            for (int i = 0; i < suppliers_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(suppliers_table.Rows[i].Cells[2].Value);
            }
            txt_supplier_pay.Text = sum.ToString("N2");
        }
        public void load_tailor_payable()
        {
            //    MySqlDataAdapter da = new MySqlDataAdapter("SELECT sp_id,sp_name,sp_rmnblnc FROM suppliers WHERE sp_rmnblnc > 0 ORDER BY sp_id ASC", con);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds, "suppliers");
            //    suppliers_table.DataSource = ds.Tables["suppliers"];
            MySqlCommand cmd = new MySqlCommand("SELECT t_id,t_name,t_rmnblnc FROM tailor WHERE t_rmnblnc > 0 ORDER BY t_id ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta2 = new DataTable();
                sda.Fill(dta2);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta2;
                tailor_table.DataSource = bsource;
                sda.Update(dta2);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            tailor_table.DataSource = dta2;

            tailor_table.Columns[0].HeaderText = "ID";
            tailor_table.Columns[1].HeaderText = "Tailor Name";
            tailor_table.Columns[2].HeaderText = "Amount Payable";

            //customer_table.Columns[0].Width = 100;
            //customer_table.Columns[1].Width = 100;

            tailor_table.Columns[1].DefaultCellStyle.Format = "N2";

            Double sum = 0;
            for (int i = 0; i < tailor_table.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(tailor_table.Rows[i].Cells[2].Value);
            }
            txt_tailor.Text = sum.ToString("N2");
        }
        public void load_low_stock_product()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT p_code,p_name,p_stock FROM products WHERE p_stock < 10 ORDER BY p_id ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "products");
            //low_stock_table.DataSource = ds.Tables["products"];
            //low_stock_table.Columns[0].HeaderText = "Item Code";
            //low_stock_table.Columns[1].HeaderText = "Product Name";
            //low_stock_table.Columns[2].HeaderText = "Items in stock";

            ////customer_table.Columns[0].Width = 100;
            ////customer_table.Columns[1].Width = 100;

            //low_stock_table.Columns[2].DefaultCellStyle.Format = "N2";

            //Double sum = 0;
            //for (int i = 0; i < suppliers_table.Rows.Count; ++i)
            //{
            //    sum += Convert.ToDouble(suppliers_table.Rows[i].Cells[1].Value);
            //}
            //txt_supplier_pay.Text = sum.ToString("N2");
        }
        public void count_sales()
        {
            try
            {
                con.Open();
                //    MySqlCommand cmnd = new MySqlCommand("SELECT SUM(grand_total) FROM (SELECT DISTINCT invoice_num, grand_total FROM sales) s;", con);
                MySqlCommand cmnd = new MySqlCommand("select ifnull(sum(grand_total),0) from sales where month(s_date) = month(now())", con);
                Object temp = cmnd.ExecuteScalar();
                label11.Text = temp.ToString();
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        public void count_customers()
        {
            try
            {
                con.Open();
                MySqlCommand cmnd = new MySqlCommand("SELECT Count(*) FROM customer", con);
                Object temp = cmnd.ExecuteScalar();
                label2.Text = temp.ToString();
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        public void count_employees()
        {
            try
            {
                con.Open();
                MySqlCommand cmnd = new MySqlCommand("SELECT Count(*) FROM users", con);
                Object temp = cmnd.ExecuteScalar();
                label5.Text = temp.ToString();
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        public void count_suppliers()
        {
            try
            {
                con.Open();
                MySqlCommand cmnd = new MySqlCommand("SELECT Count(*) FROM suppliers", con);
                Object temp = cmnd.ExecuteScalar();
                label7.Text = temp.ToString();
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        public void count_products()
        {
            try
            {
                con.Open();
                MySqlCommand cmnd = new MySqlCommand("SELECT Count(*) FROM products", con);
                Object temp = cmnd.ExecuteScalar();
                label9.Text = temp.ToString();
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void customer_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Pay_customer_balance fr = new Pay_customer_balance(this);
            int row = customer_table.CurrentRow.Index;
            fr.Shown += (senderfr, efr) =>
            {
                fr.txt_cid.Text = Convert.ToString(customer_table[0, row].Value);
                fr.txt_name.Text = Convert.ToString(customer_table[1, row].Value);
                fr.txt_bln.Text = Convert.ToString(customer_table[2, row].Value);
                // fr.txt_email.Text = Convert.ToString(customer_table[3, row].Value);

            };
            fr.Show();
        }

        private void customer_table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            //search_customer();
        }
        private void search_from_customer()
        {
            //MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer ", con);
            ////  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
            //con.Open();
            //MySqlDataReader reader = cmd.ExecuteReader();
            //AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

            //while (reader.Read())
            //{
            //    collection.Add(reader.GetString(1));
            //    //collection.Add(reader.GetString(1));
            //    //collection.Add(reader.GetString(2));
            //    //collection.Add(reader.GetString(3));
            //    //collection.Add(reader.GetString(4));
            //}
            //txt_search_customer.AutoCompleteCustomSource = collection;
            //con.Close();
        }

        private void txt_search_customer_Enter(object sender, EventArgs e)
        {
            if (txt_search_customer.Text == "Search Customer")
            {
                txt_search_customer.Text = "";
            }
        }

        private void txt_search_customer_Leave(object sender, EventArgs e)
        {
            if (txt_search_customer.Text == "")
            {
                txt_search_customer.Text = "Search Customer";

            }
        }

        private void txt_search_customer_TextChanged(object sender, EventArgs e)
        {
            //    if (txt_search_customer.Text == "")
            //    {
            //        load_customers_receiveable();
            //    }
        }
        public void search_suppliers()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT sp_name,sp_rmnblnc FROM suppliers WHERE sp_name like '" + txt_search_suppliers.Text + "%' AND sp_rmnblnc > 0 ORDER BY sp_id ASC ", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "suppliers");
            //suppliers_table.DataSource = ds.Tables["suppliers"];
            //suppliers_table.Columns[0].HeaderText = "Supplier Name";
            //suppliers_table.Columns[1].HeaderText = "Amount Payable";

            ////customer_table.Columns[0].Width = 100;
            ////customer_table.Columns[1].Width = 100;

            //suppliers_table.Columns[1].DefaultCellStyle.Format = "N2";
        }

        private void txt_search_suppliers_Enter(object sender, EventArgs e)
        {

            if (txt_search_suppliers.Text == "Search Suppliers")
            {
                txt_search_suppliers.Text = "";
            }
        }

        private void txt_search_suppliers_KeyDown(object sender, KeyEventArgs e)
        {
            //  search_suppliers();
        }

        private void txt_search_suppliers_Leave(object sender, EventArgs e)
        {
            if (txt_search_suppliers.Text == "")
            {
                txt_search_suppliers.Text = "Search Suppliers";
                // load_suppliers_payable();

            }
        }

        private void txt_search_suppliers_TextChanged(object sender, EventArgs e)
        {
            //if (txt_search_suppliers.Text == "")
            //{
            //    load_suppliers_payable();
            //}
        }

        private void suppliers_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            pay_spplier_balance fr = new pay_spplier_balance();
            int row = suppliers_table.CurrentRow.Index;
            fr.Shown += (senderfr, efr) =>
            {
                fr.txt_spid.Text = Convert.ToString(suppliers_table[0, row].Value);
                fr.txt_sp_name.Text = Convert.ToString(suppliers_table[1, row].Value);
                fr.txt_sp_bln.Text = Convert.ToString(suppliers_table[2, row].Value);
                // fr.txt_email.Text = Convert.ToString(customer_table[3, row].Value);

            };
            fr.Show();
        }

        private void txt_search_customer_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("c_name LIKE '%" + txt_search_customer.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            customer_table.DataSource = dv;
        }

        private void txt_search_suppliers_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta1);

            dv.RowFilter = string.Concat("sp_name LIKE '%" + txt_search_suppliers.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            suppliers_table.DataSource = dv;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //load_customers_receiveable();
            //load_suppliers_payable();
            //load_tailor_payable();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (txt_search_tailor.Text == "")
            {
                txt_search_tailor.Text = "Search Tailor";              
            }
        }

        private void txt_search_tailor_Enter(object sender, EventArgs e)
        {
            if (txt_search_tailor.Text == "Search Tailor")
            {
                txt_search_tailor.Text = "";
            }
        }

        private void txt_search_tailor_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta2);

            dv.RowFilter = string.Concat("t_name LIKE '%" + txt_search_tailor.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            tailor_table.DataSource = dv;
        }

        private void tailor_table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tailor_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            pay_tailor_balance fr = new pay_tailor_balance(this);
            int row = tailor_table.CurrentRow.Index;
            fr.Shown += (senderfr, efr) =>
            {
                fr.txt_tid.Text = Convert.ToString(tailor_table[0, row].Value);
                fr.txt_name.Text = Convert.ToString(tailor_table[1, row].Value);
                fr.txt_bln.Text = Convert.ToString(tailor_table[2, row].Value);
                // fr.txt_email.Text = Convert.ToString(customer_table[3, row].Value);

            };
            fr.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           // Backup();
        }
        private void Backup()
        {
            //string constring = "server=localhost;  user id =root; password=; database=pos1;";
            //if (savefiledialog1.ShowDialog() == DialogResult.OK)
            //{
            //    string file = savefiledialog1.FileName;
            //    using (MySqlConnection conn = new MySqlConnection(constring))
            //    {
            //        using (MySqlCommand cmd = new MySqlCommand())
            //        {
            //            using (MySqlBackup mb = new MySqlBackup(cmd))
            //            {
            //                cmd.Connection = conn;
            //                conn.Open();
            //                mb.ExportToFile(file);
            //                conn.Close();
            //            }
            //        }
            //    }
            //}
                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Backup();
        }
    }
}
