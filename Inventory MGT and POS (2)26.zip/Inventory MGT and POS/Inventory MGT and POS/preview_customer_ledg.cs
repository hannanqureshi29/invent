﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class preview_customer_ledg : Form
    {
        private MySqlConnection con;
        DataTable dt = new DataTable();
        public preview_customer_ledg()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void preview_customer_ledg_Load(object sender, EventArgs e)
        {
            load_ledger();
        }
        private void load_ledger()
        {
            try
            {

               


                MySqlParameter[] prm = new MySqlParameter[2];

                //  prm[0] = new MySqlParameter("pid", MySqlDbType.VarChar);
                //  prm[0].Value = txt_id.Text;
                prm[0] = new MySqlParameter("cid", MySqlDbType.VarChar);
                prm[0].Value = txt_id.Text;

                prm[1] = new MySqlParameter("cusname", MySqlDbType.VarChar);
                prm[1].Value = txt_name.Text;

                // prm[3] = new MySqlParameter("pcode", MySqlDbType.VarChar);
                // prm[3].Value = txt_pcode.Text;
                //prm[2] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                //prm[2].Value = txt_Rev_Sta.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "load_cus_ledger";
                cmnd.Parameters.AddRange(prm);

                con.Open();
                MySqlDataReader sdr = cmnd.ExecuteReader();
                dt.Load(sdr);
                table_cusledger.DataSource = dt;
                dt.Dispose();
                sdr.Dispose();
                cmnd.Dispose();


                table_cusledger.Columns[0].HeaderText = "Ledger ID";
                table_cusledger.Columns[1].HeaderText = "Customer ID";
                table_cusledger.Columns[2].HeaderText = "Date";
                table_cusledger.Columns[3].HeaderText = "Customer Name";

                table_cusledger.Columns[4].HeaderText = "Credit";
                table_cusledger.Columns[5].HeaderText = "Debit";
                table_cusledger.Columns[6].HeaderText = "Remaining Balance";
                table_cusledger.Columns[7].HeaderText = "Description";
                //Products_Table.Columns[8].HeaderText = "Total";


                table_cusledger.Columns[0].Width = 50;
                table_cusledger.Columns[1].Width = 50;
                table_cusledger.Columns[2].Width = 80;
                table_cusledger.Columns[3].Width = 100;
                table_cusledger.Columns[4].Width = 100;
                table_cusledger.Columns[5].Width = 100;
                table_cusledger.Columns[6].Width = 100;
                table_cusledger.Columns[7].Width = 100;
            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }
    }
}
