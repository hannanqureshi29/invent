﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Pay_customer_balance : Form
    {
        private MySqlConnection con;
        public Pay_customer_balance(Dash dash)
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void customer_table_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txt_search_customer_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                decimal a = Convert.ToDecimal(txt_bln.Text);
                decimal b = Convert.ToDecimal(txt_amount_paid.Text);
                decimal c = a - b;

                con.Open();
                string query = ("UPDATE customer set c_rmnblnc  = '" + c + "' WHERE c_id  = '" + txt_cid.Text + "' ;");
                MySqlCommand cmnd = new MySqlCommand(query, con);
                MySqlDataReader read;

                read = cmnd.ExecuteReader();


                read.Close();
                cmnd.Dispose();


                using (MySqlCommand cmd1 = new MySqlCommand("INSERT INTO customer_ledger(c_id,cus_name,date,cus_credit,cus_debit,cus_balance)values(@cid,@cusname,NOW(),@cuscredit,@cusdebit,@cusbalance)", con))
                {
                    cmd1.Parameters.AddWithValue("@cid", Convert.ToInt64(txt_cid.Text));

                    cmd1.Parameters.AddWithValue("@cusname", txt_name.Text);
                    cmd1.Parameters.AddWithValue("@cuscredit", 0);
                    cmd1.Parameters.AddWithValue("@cusdebit", Convert.ToDouble(txt_amount_paid.Text));
                    cmd1.Parameters.AddWithValue("@cusbalance", c.ToString());
                  //  cmd1.Parameters.AddWithValue("@description", "Sale Against Invoice Number:" + txt_invoice.Text);

                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();
                }

                con.Close();

                MessageBox.Show(c.ToString());
                Dash master = (Dash)Application.OpenForms["Dash"];
                master.btn_refresh.PerformClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Dash>().Any())
            {
                Dash master = (Dash)Application.OpenForms["Dash"];
                master.load_customers_receiveable();
            }
            else
            {

            }
            this.Close();
        }

        private void Pay_customer_balance_Load(object sender, EventArgs e)
        {

        }
    }
}
