﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class update_creditbook : Form
    {
        private MySqlConnection con;
        MySqlCommand cmd;
        MySqlCommand cmnd;
        public update_creditbook()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("insert into credit_history(credit_id,name,issued_date,cash,receiving_date,status) values(@creditid,@name,@issueddate,@cash,@receivingdate,@status)", con);

                cmd.Parameters.AddWithValue("@creditid", txt_id.Text);
                cmd.Parameters.AddWithValue("@name", txt_name.Text);
                cmd.Parameters.AddWithValue("@issueddate", txt_issued.Text);
                cmd.Parameters.AddWithValue("@cash", txt_cash.Text);
                cmd.Parameters.AddWithValue("@receivingdate", txt_validity.Text);
                cmd.Parameters.AddWithValue("@status", combo_status.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                load_rec();


                decimal a = Convert.ToDecimal(txt_cash.Text);
                decimal b = Convert.ToDecimal(txt_amount_paid.Text);
                decimal c = a - b;

                // string query = ("UPDATE credit_book SET cash= '" + c.ToString() + "', issued_date='6', receiving_date=@receivingdate, status=@status WHERE credit_id  = '" + txt_id.Text + "'");
                // MySqlCommand cmnd = new MySqlCommand(query, con);
                //  MySqlDataReader read;

                // read = cmnd.ExecuteReader();
                // 
                // read.Close();
                // cmnd.Dispose();

                string query = ("UPDATE credit_book set cash = '" + c.ToString() + "' , issued_date = '" + txt_issued.Text + "' , receiving_date = '" + txt_validity.Text + "', status = '" + combo_status.Text + "' WHERE credit_id  = '" + txt_id.Text + "';");
                //  MySqlCommand cmnd = new MySqlCommand("UPDATE credit_book SET cash=@cash, issued_date=@issueddate, receiving_date=@receivingdate, status=@status");


                //cmnd.Parameters.AddWithValue("@cash", c.ToString());
                //cmnd.Parameters.AddWithValue("@issueddate", txt_issued.Value);
                //cmnd.Parameters.AddWithValue("@receivingdate", txt_validity.Value);
                //cmnd.Parameters.AddWithValue("@status", combo_status.Text);


                MySqlCommand cmnd = new MySqlCommand(query, con);
                MySqlDataReader read;
                con.Open();
                read = cmnd.ExecuteReader();
                con.Close();

                read.Close();
                cmnd.Dispose();

                MessageBox.Show(c.ToString());
                //load_rec();

            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void update_creditbook_Load(object sender, EventArgs e)
        {
            load_rec();
        }
        private void load_rec()
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT credit_id,name,issued_date,cash,receiving_date,status FROM credit_history WHERE credit_id = '" + txt_id.Text + "' ", con); //WHERE credit_id='" +txt_id.Text+ "'
            DataSet ds = new DataSet();
            da.Fill(ds, "credit_history");
            credit_record.DataSource = ds.Tables["credit_history"];

            credit_record.Columns[0].HeaderText = "ID";
            credit_record.Columns[1].HeaderText = "Name";
            credit_record.Columns[2].HeaderText = "Issued Date";
            credit_record.Columns[3].HeaderText = "Cash";
            credit_record.Columns[4].HeaderText = "Receiving Date";
            credit_record.Columns[5].HeaderText = "Status";

            credit_record.Columns[0].Width = 30;
            credit_record.Columns[1].Width = 50;
            credit_record.Columns[2].Width = 80;
            credit_record.Columns[3].Width = 80;
            credit_record.Columns[4].Width = 80;
            credit_record.Columns[5].Width = 80;

            credit_record.Columns[3].DefaultCellStyle.Format = "N2";


            credit_record.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;


            credit_record.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            credit_record.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }
    }
}
