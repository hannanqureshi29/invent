﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Preview_tailor_ledger : Form
    {
        private MySqlConnection con;
        DataTable dt = new DataTable();
        public Preview_tailor_ledger()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void Preview_tailor_ledger_Load(object sender, EventArgs e)
        {
            load_ledger();
        }
        private void load_ledger()
        {
            try
            {

                MySqlParameter[] prm = new MySqlParameter[2];

                prm[0] = new MySqlParameter("tid", MySqlDbType.VarChar);
                prm[0].Value = txt_id.Text;

                prm[1] = new MySqlParameter("tname", MySqlDbType.VarChar);
                prm[1].Value = txt_name.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "load_tailor_ledger";
                cmnd.Parameters.AddRange(prm);

                con.Open();
                MySqlDataReader sdr = cmnd.ExecuteReader();
                dt.Load(sdr);
                table_tailedger.DataSource = dt;
                dt.Dispose();
                sdr.Dispose();
                cmnd.Dispose();


                table_tailedger.Columns[0].HeaderText = "Ledger ID";
                table_tailedger.Columns[1].HeaderText = "Tailor ID";
                table_tailedger.Columns[2].HeaderText = "Date";
                table_tailedger.Columns[3].HeaderText = "Tailor Name";

                table_tailedger.Columns[4].HeaderText = "Credit";
                table_tailedger.Columns[5].HeaderText = "Debit";
                table_tailedger.Columns[6].HeaderText = "Remaining Balance";
                table_tailedger.Columns[7].HeaderText = "Description";



                table_tailedger.Columns[0].Width = 50;
                table_tailedger.Columns[1].Width = 50;
                table_tailedger.Columns[2].Width = 80;
                table_tailedger.Columns[3].Width = 100;
                table_tailedger.Columns[4].Width = 100;
                table_tailedger.Columns[5].Width = 100;
                table_tailedger.Columns[6].Width = 100;
                table_tailedger.Columns[7].Width = 100;
            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}
