﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class preview_sale : Form
    {
        private MySqlConnection con;
        DataTable dt = new DataTable();
        public preview_sale()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void preview_sale_Load(object sender, EventArgs e)
        {
            load_from_sale();
            customer_balnce();
        }
        public void customer_balnce()
        {
            try
            {
                con.Open();
                MySqlCommand cmnd = new MySqlCommand("SELECT c_rmnblnc FROM customer WHERE c_id = '" + txt_cid.Text + "'", con);
                Object temp = cmnd.ExecuteScalar();
                txt_cbalance.Text = temp.ToString();
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void load_from_sale()
        {
            try
            {
                MySqlParameter[] pms = new MySqlParameter[2];
                //pms[0] = new MySqlParameter("cid", MySqlDbType.Int32);
                //pms[0].Value = txt_cid.Text;
                pms[0] = new MySqlParameter("cid", MySqlDbType.VarChar);
                pms[0].Value = txt_cid.Text;
                pms[1] = new MySqlParameter("invoicenum", MySqlDbType.VarChar);
                pms[1].Value = lbl_invoice_num.Text;

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "load_from_sale";
                cmd.Parameters.AddRange(pms);

                con.Open();
                using (MySqlDataReader read = cmd.ExecuteReader())

                {
                    if (read.Read())
                    {
                        txt_name.Text = (read["cname"]).ToString();
                        // txt_cbalance.Text = (read["crmnblnc"]).ToString();
                        // lbl_invoice_num.Text = (read["invoicenum"]).ToString();
                        label7.Text = (read["totalitems"]).ToString();
                        //label9.Text = (read["subtotal"]).ToString();
                        //label11.Text = (read["taxamount"]).ToString();
                        txt_grand_total.Text = (read["grandtotal"]).ToString();
                        txt_cash_rec.Text = (read["amountreceived"]).ToString();

                        txt_change.Text = (read["changereturned"]).ToString();
                        //   txt_cash_rec.Text = (read["cbalance"]).ToString();

                    }
                }
                cmd.Dispose();


                MySqlParameter[] prm = new MySqlParameter[2];

                prm[0] = new MySqlParameter("cid", MySqlDbType.VarChar);
                prm[0].Value = txt_cid.Text;
                prm[1] = new MySqlParameter("invoicenum", MySqlDbType.VarChar);
                prm[1].Value = lbl_invoice_num.Text;
                //prm[1] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
                //prm[1].Value = txt_Update_Status.Text;
                //prm[2] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                //prm[2].Value = txt_Rev_Sta.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "POS_table";
                cmnd.Parameters.AddRange(prm);

                MySqlDataReader sdr = cmnd.ExecuteReader();
                dt.Load(sdr);
                sale_record_table.DataSource = dt;
                dt.Dispose();
                sdr.Dispose();
                cmnd.Dispose();



                sale_record_table.Columns[0].HeaderText = "Code";
                sale_record_table.Columns[1].HeaderText = "Product Name";
                // sale_record_table.Columns[2].HeaderText = "Category";
                sale_record_table.Columns[2].HeaderText = "Product Description";
                sale_record_table.Columns[3].HeaderText = "Unit Price";
                sale_record_table.Columns[4].HeaderText = "QTY";
                sale_record_table.Columns[5].HeaderText = "Total%";
                //Products_Table.Columns[7].HeaderText = "Unit Price";
                //Products_Table.Columns[8].HeaderText = "Total";


                sale_record_table.Columns[0].Width = 50;
                sale_record_table.Columns[1].Width = 150;
                // sale_record_table.Columns[2].Width = 200;
                sale_record_table.Columns[2].Width = 100;
                sale_record_table.Columns[3].Width = 100;
                sale_record_table.Columns[4].Width = 50;
                sale_record_table.Columns[5].Width = 100;



            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }
    }
}
