﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Main : Form
    {
        private MySqlConnection con;
        public Main()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void call_form_in_panel(object aja_form)
        {
            if (this.panelContenedor.Controls.Count > 0)
                this.panelContenedor.Controls.RemoveAt(0);
            Form fh = aja_form as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panelContenedor.Controls.Add(fh);
            this.panelContenedor.Tag = fh;
            fh.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label5.Text = Login.u_name;
            button1_Click(null, e);
            user_roll();
            if (label4.Text == "Admin")
            {
                button2.Enabled = true;
                btnprod.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button15.Enabled = true;
                button10.Enabled = true;
                button12.Enabled = true;

                button12.Enabled = true;
                button14.Enabled = true;
                button13.Enabled = true;
                button17.Enabled = true;
                button9.Enabled = true;
                button16.Enabled = true;
                button18.Enabled = true;
                button19.Enabled = true;
                button6.Enabled = true;
                button20.Enabled = true;
                //Dash frm = new Dash(this);
                //this.Enabled = true;
                //frm.Show();
            }
            if (label4.Text == "User")
            {

                button2.Enabled = false;
                btnprod.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button15.Enabled = false;
                button10.Enabled = false;
                button12.Enabled = false;

                button12.Enabled = false;
                button14.Enabled = false;
                button13.Enabled = false;
                button17.Enabled = false;
                button9.Enabled = false;
                button16.Enabled = false;
                button18.Enabled = false;
                button19.Enabled = false;
                button6.Enabled = false;
                button20.Enabled = false;
                //Dash frm = new Dash(this);
                //this.Enabled = false;
                //frm.Show();

            }

        }
        private void user_roll()
        {
            string _username = label5.Text.Trim();
            try
            {
                MySqlCommand cmd = new MySqlCommand("SELECT u_roll FROM users WHERE u_name = '" + label5.Text + "' ", con);
                con.Open();
                using (MySqlDataReader read = cmd.ExecuteReader())
                {
                    while (read.Read())
                    {
                        label4.Text = (read["u_roll"]).ToString();
                    }
                    read.Close();
                }
            }
            catch
            {
                con.Close();
                con.Dispose();
                MessageBox.Show("Error Loading User Role");
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (MenuVertical.Width == 250)
            {
                MenuVertical.Width = 70;
                button1.Text = "";
                //button9.Text = "";
            }
            else
                MenuVertical.Width = 250;
            button1.Text = "Dashboard";
            //  button9.Text = "Ledgers";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Dash(this));
        }

        private void btnprod_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Products());
        }

        private void iconminimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void iconcerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconrestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            iconrestaurar.Visible = false;
            iconmaximizar.Visible = true;
        }

        private void BarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void iconmaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            iconrestaurar.Visible = true;
            iconmaximizar.Visible = false;
        }

        private void BarraTitulo_Paint(object sender, PaintEventArgs e)
        {

        }
        private void hideSubMenu()
        {
            panel4.Visible = false;
            //panelPlaylistSubMenu.Visible = false;
            //panelToolsSubMenu.Visible = false;
        }
        private void showSubMenu(Panel panel4)
        {
            if (panel4.Visible == false)
            {
                //hideSubMenu();
                panel4.Visible = true;
            }
            else
                panel4.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            showSubMenu(panel4);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Customers());
        }

        private void button7_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new POS());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Sales());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Suppliers());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Purchases_table());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Admin_Panel());
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Contact_Developer dev = new Contact_Developer();
            dev.Show();
        }

        private void panelContenedor_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new POP());
        }

        private void button16_Click(object sender, EventArgs e)
        {
            //var de = new Pay_customer_balance();
            //de.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Product_Ledger());
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Taylor());
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new taylor_sale());
        }

        private void button13_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new returned__from_tailor());
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            call_form_in_panel(new stitched_sale());
        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            call_form_in_panel(new new_stitch_sale());
        }

        private void button17_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new load_stitched_product());
        }

        private void button18_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new Credit_book());
        }

        private void button19_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new update_gaj());
        }

        private void button20_Click(object sender, EventArgs e)
        {
            call_form_in_panel(new sALES_RECORD());
        }

        private void button21_Click(object sender, EventArgs e)
        {
            this.Close();
            var dash = new Login();
            dash.Show();
        }
    }
}
