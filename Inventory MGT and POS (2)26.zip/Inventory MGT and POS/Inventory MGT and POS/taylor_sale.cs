﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class taylor_sale : Form
    {
        AutoCompleteStringCollection collection = new AutoCompleteStringCollection();
        List<string> listOnit = new List<string>();
        private MySqlConnection con;
        public taylor_sale()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void taylor_sale_Load(object sender, EventArgs e)
        {
            p_code_search();
            product_name_search();
            tailor_name_search();
            max_invoice_id();
            supplier_name_search();
            TableProducts.Columns[0].Width = 50;
            TableProducts.Columns[1].Width = 100;
            TableProducts.Columns[2].Width = 100;
            // TableProducts.Columns[3].Width = 100;
            TableProducts.Columns[3].Width = 80;
            TableProducts.Columns[4].Width = 60;
            TableProducts.Columns[5].Width = 60;
            TableProducts.Columns[6].Width = 60;
            TableProducts.Columns[7].Width = 60;
            TableProducts.Columns[8].Width = 100;
        }
        private void product_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_name FROM products", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_pname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        public void tailor_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT t_name FROM tailor", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            comb_cname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        private void max_invoice_id()
        {
            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(invoice_num)+1 FROM saletotailor ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txt_invoice.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }

        private void txt_unitprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
            TextBox txtDecimal = sender as TextBox;
            if (e.KeyChar == '.' && txtDecimal.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txt_qty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
        }

        private void txt_ptotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
            TextBox txtDecimal = sender as TextBox;
            if (e.KeyChar == '.' && txtDecimal.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_qty.Text.Trim() != string.Empty)
                {
                    Double A = Convert.ToDouble(txt_unitprice.Text);
                    Double B = Convert.ToDouble(txt_qty.Text);
                    txt_ptotal.Text = (A * B).ToString("N2");
                }
                else if (txt_qty.Text.Trim() == string.Empty)
                {
                    txt_ptotal.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txt_qty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                double u_stock;
                double old_stock = Convert.ToDouble(txt_stock.Text);
                double new_stock = Convert.ToDouble(txt_qty.Text);

                u_stock = old_stock - new_stock;
                string[] row1 = { txt_stock.Text, u_stock.ToString() };
                hidden_table.Rows.Add(row1);

                string[] row = { txt_item_code.Text, txt_pname.Text, txt_pdesc.Text, txt_unitprice.Text, txt_qty.Text, txt_sub_product.Text, txt_per.Text, txt_items.Text, txt_ptotal.Text };
                TableProducts.Rows.Add(row);

                Double sum = 0;
                for (int i = 0; i < TableProducts.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(TableProducts.Rows[i].Cells[8].Value);
                }
                label7.Text = (TableProducts.RowCount).ToString();
                txt_grand_total.Text = sum.ToString("N2");
                ////For Tax Amount Calculation with respect to 17% 
                //label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
                //label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

                txt_item_code.Clear();
                txt_pname.Clear();
                txt_pcat.Clear();
                txt_stock.Clear();
                txt_unitprice.Clear();
                txt_qty.Clear();
                txt_ptotal.Clear();
                txt_pdesc.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //try
            // {
            con.Open();
            for (int i = 0; i < TableProducts.Rows.Count; i++)
            {
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO saletotailor(invoice_num,supplier_name,s_date,t_id,t_name,t_rmnblnc,s_phone,p_name,p_code,p_desc,p_saleprice,total_items,p_qty,sub_name,per_gaj,items,total)values(@inv_num,@suppliername,NOW(),@t_id,@t_name,@t_blnc,@sphone,@pname,@p_code,@pdesc,@sale_price,@tot_items,@qty,@subname,@pergaj,@items,@item_total)", con))
                {
                    cmd.Parameters.AddWithValue("@inv_num", txt_invoice.Text);
                    cmd.Parameters.AddWithValue("@suppliername", txt_pcat.Text);
                    // cmd.Parameters.AddWithValue("@date", System.DateTime.Now.ToString());
                    cmd.Parameters.AddWithValue("@t_id", Convert.ToInt64(txt_cid.Text));
                    cmd.Parameters.AddWithValue("@t_name", comb_cname.Text);
                    cmd.Parameters.AddWithValue("@t_blnc", txt_cbalance.Text);
                    cmd.Parameters.AddWithValue("@sphone", txt_phone.Text);
                    //cmd.Parameters.AddWithValue("@pid", Convert.ToInt64(textBox15.Text));
                    cmd.Parameters.AddWithValue("@p_code", Convert.ToString(TableProducts.Rows[i].Cells[0].Value));
                    cmd.Parameters.AddWithValue("@pname", TableProducts.Rows[i].Cells[1].Value.ToString());

                    //cmd.Parameters.AddWithValue("@cat", TableProducts.Rows[i].Cells[2].Value.ToString());
                    cmd.Parameters.AddWithValue("@pdesc", TableProducts.Rows[i].Cells[2].Value.ToString());
                    //  cmd.Parameters.AddWithValue("@prchase_price", Convert.ToInt32(textBox16.Text));
                    cmd.Parameters.AddWithValue("@sale_price", Convert.ToInt32(TableProducts.Rows[i].Cells[3].Value));
                    cmd.Parameters.AddWithValue("@tot_items", Convert.ToInt32(label7.Text));
                    cmd.Parameters.AddWithValue("@qty", Convert.ToDouble(TableProducts.Rows[i].Cells[4].Value));
                    cmd.Parameters.AddWithValue("@subname", TableProducts.Rows[i].Cells[5].Value.ToString());
                    cmd.Parameters.AddWithValue("@pergaj", Convert.ToDouble(TableProducts.Rows[i].Cells[6].Value));
                    cmd.Parameters.AddWithValue("@items", Convert.ToDouble(TableProducts.Rows[i].Cells[7].Value));
                    cmd.Parameters.AddWithValue("@item_total", Convert.ToDouble(TableProducts.Rows[i].Cells[8].Value));
                    // cmd.Parameters.AddWithValue("@subtotal", Convert.ToDouble(label9.Text));
                    // cmd.Parameters.AddWithValue("@taxamount", Convert.ToDouble(label11.Text));
                    //  cmd.Parameters.AddWithValue("@grand_total", Convert.ToDouble(txt_grand_total.Text));
                    // cmd.Parameters.AddWithValue("@amnt_rcv", Convert.ToDouble(txt_cash_rec.Text));
                    //cmd.Parameters.AddWithValue("@chng_rtrn", Convert.ToDouble(txt_change.Text));
                    // cmd.Parameters.AddWithValue("@cashier", label5.Text.ToString());
                    // con.Open();
                    cmd.ExecuteNonQuery();
                    // con.Close();
                    cmd.Dispose();
                }
            }
            for (int i = 0; i < TableProducts.Rows.Count; i++)
            {

                string query = ("UPDATE products set total_gaj ='" + hidden_table.Rows[i].Cells[1].Value + "' WHERE p_code = '" + TableProducts.Rows[i].Cells[0].Value + "' ;");
                MySqlCommand cmnd = new MySqlCommand(query, con);
                MySqlDataReader read;

                read = cmnd.ExecuteReader();
                // 
                read.Close();
                cmnd.Dispose();
            }
            //double a = Convert.ToDouble(txt_change.Text);

            //if (a<0)
            //{
            //    double b = Convert.ToDouble(txt_cbalance.Text);
            //    double c = b - a;
            //    string query = ("UPDATE customer SET c_rmnblnc ='" + c.ToString() + "' WHERE c_id  = '" + txt_cid.Text + "' ;");
            //    MySqlCommand cmnd1 = new MySqlCommand(query, con);
            //    MySqlDataReader read1;
            //   // MessageBox.Show("test");
            //    read1 = cmnd1.ExecuteReader();
            //    read1.Close();
            //    cmnd1.Dispose();
            //}

            con.Close();
            MessageBox.Show("Success");
            ////For Printing Receipt
            //printPreviewDialog1.Document = printDocument1;
            //printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 285, 600);
            //printPreviewDialog1.ShowDialog();
            //  TableProducts.AllowUserToAddRows = false;
            //Reload Page after one entry
            max_invoice_id();
            emptycart();
            // }
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //    con.Close();
            //}
            //For Saving Values in Database-Sales Table
        }
        private void emptycart()
        {
            txt_item_code.Clear();
            txt_pname.Clear();
            txt_pcat.Clear();
            txt_stock.Clear();
            txt_unitprice.Clear();
            txt_qty.Clear();
            txt_ptotal.Clear();
            txt_pdesc.Clear();
            txt_cid.Clear();

            comb_cname.ResetText();
            txt_cbalance.Clear();
            txt_phone.Clear();

            TableProducts.Rows.Clear();
            TableProducts.Refresh();
            txt_invoice.Refresh();

            hidden_table.Rows.Clear();
            hidden_table.Refresh();

            label7.Text = "0";
            // label9.Text = "0";
            //label11.Text = "0";

            // txt_grand_total.Clear();
            //  txt_grand_total.Refresh();
            //  txt_cash_rec.Clear();
            //  txt_change.Clear();
        }

        private void txt_pname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_code,p_desc,total_gaj FROM products WHERE p_name = '" + txt_pname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_item_code.Text = dr.GetValue(0).ToString();
                    // txt_pcat.Text = dr.GetValue(1).ToString();
                    txt_pdesc.Text = dr.GetValue(1).ToString();
                    txt_stock.Text = dr.GetValue(2).ToString();
                    // txt_unitprice.Text = dr.GetValue(4).ToString();

                }
                con.Close();
            }
        }
        private void p_code_search()
        {
            //MySqlCommand cmd = new MySqlCommand("SELECT DISTINCT p_code FROM products", con);
            //con.Open();
            //MySqlDataReader reader = cmd.ExecuteReader();
            //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            //while (reader.Read())
            //{
            //    MyCollection.Add(reader.GetString(0));
            //}
            //txt_item_code.AutoCompleteCustomSource = MyCollection;
            //con.Close();
        }
        private void txt_item_code_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_name,total_gaj,p_desc FROM products WHERE p_code = '" + txt_item_code.Text + "' AND supplier_name ='" + txt_pcat.Text + "'", con); //ORDER BY COUNT(DISTINCT p_id )
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_pname.Text = dr.GetValue(0).ToString();
                    // txt_pcat.Text = dr.GetValue(1).ToString();
                    txt_stock.Text = dr.GetValue(1).ToString();
                    txt_pdesc.Text = dr.GetValue(2).ToString();
                    // txt_unitprice.Text = dr.GetValue(3).ToString();
                }
                con.Close();
            }
            //if (e.KeyCode == Keys.Enter)
            //{
            //    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(`update_item`,0)AS update_item FROM saletotailor WHERE p_code = '" + txt_item_code.Text + "' AND supplier_name ='" + txt_pcat.Text + "'", con); //ORDER BY COUNT(DISTINCT p_id )
            //    con.Open();
            //    MySqlDataReader dr = cmd.ExecuteReader();
            //    while (dr.Read())
            //    {
            //        textBox1.Text = dr.GetValue(0).ToString();
                   
                  
                   
                    
            //    }
            //    con.Close();
            //}
        }

        private void txt_cash_rec_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    txt_change.Text = (Convert.ToDouble(txt_cash_rec.Text) - Convert.ToDouble(txt_grand_total.Text)).ToString("N2");
            //}
        }

        private void comb_cname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT t_id,t_rmnblnc,t_phone FROM tailor WHERE t_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_cid.Text = dr.GetValue(0).ToString();
                    txt_cbalance.Text = dr.GetValue(1).ToString();
                    txt_phone.Text = dr.GetValue(2).ToString();
                }
                con.Close();
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }
        private void calculations()
        {
            Double sum = 0;
            for (int i = 0; i < TableProducts.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(TableProducts.Rows[i].Cells[6].Value);
            }
            label7.Text = (TableProducts.RowCount).ToString();
            txt_grand_total.Text = sum.ToString("N2");
            //For Tax Amount Calculation with respect to 17% 
            //  label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
            // label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");
        }

        private void TableProducts_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            calculations();
        }

        private void taylor_sale_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.Modifiers == Keys.Control && e.KeyCode == Keys.Q)
            //{
            //    this.ActiveControl = txt_cash_rec;
            //}
        }

        private void TableProducts_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //foreach (DataGridViewRow row in TableProducts.Rows)
            //    try
            //    {
            //        double a;
            //        a = Convert.ToDouble(row.Cells[TableProducts.Columns[4].Index].Value) * Convert.ToDouble(row.Cells[TableProducts.Columns[5].Index].Value);
            //        row.Cells[TableProducts.Columns[6].Index].Value = a.ToString("N2");

            //        Double sum = 0;
            //        for (int i = 0; i < TableProducts.Rows.Count; ++i)
            //        {
            //            sum += Convert.ToDouble(TableProducts.Rows[i].Cells[6].Value);


            //        }
            //        label7.Text = (TableProducts.RowCount).ToString();
            //        txt_grand_total.Text = sum.ToString();
            //        label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
            //        label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

            //        for (int x = 0; x < hidden_table.Rows.Count; ++x)
            //        {
            //            int b;
            //            b = Convert.ToInt32(hidden_table.Rows[x].Cells[0].Value) - Convert.ToInt32(TableProducts.Rows[x].Cells[5].Value);
            //            hidden_table.Rows[x].Cells[1].Value = b;
            //        }



            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.ToString());
            //    }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<addnew_tailor>().Any())
            {
                Application.OpenForms.OfType<addnew_tailor>().First().BringToFront();
            }
            else
            {
                var dash = new addnew_tailor();
                dash.Show();

            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                double input1 = Convert.ToDouble(txt_qty.Text);
                double input2 = Convert.ToDouble(txt_per.Text);

                double result = input1 / input2;

                txt_items.Text = result.ToString("0.00");
            }
        }

        private void txt_per_TextChanged(object sender, EventArgs e)
        {

            //try
            //{
            //    if (txt_per.Text.Trim() != string.Empty)
            //    {
            //        double input1 = Convert.ToDouble(txt_qty.Text);
            //        double input2 = Convert.ToDouble(txt_per.Text);

            //        double result = input1 / input2;

            //        txt_items.Text = result.ToString("0.00");
            //    }
            //    else if (txt_per.Text.Trim() == string.Empty)
            //    {
            //        txt_items.Text = "0";
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString());
            //}
        }

        private void txt_pcat_KeyDown(object sender, KeyEventArgs e)
        {

        }
        public void supplier_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_pcat.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void txt_pcat_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products WHERE supplier_name = '" + txt_pcat.Text + "'", con);
                // con.Open();

                MySqlCommand cmd1 = new MySqlCommand("SELECT p_code FROM products WHERE supplier_name = '" + txt_pcat.Text + "' AND total_gaj > 0", con);
                con.Open();
                MySqlDataReader reader = cmd1.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txt_item_code.AutoCompleteCustomSource = MyCollection;
                //con.Close();

                con.Close();
            }
        }

        private void lblhora_Click(object sender, EventArgs e)
        {

        }

        private void txt_items_TextChanged(object sender, EventArgs e)
        {
            //double input1 = Convert.ToDouble(txt_items.Text);
            //double input2 = Convert.ToDouble(textBox1.Text);

            //double result = input1 + input2;

            //textBox2.Text = result.ToString("0.00");
        }
    }
}
