﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class load_stitched_product : Form
    {
        DataTable dta;
        private MySqlConnection con;
        public load_stitched_product()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void load_stitched_product_Load(object sender, EventArgs e)
        {
            load_sales();
        }
        public void load_sales()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT DISTINCT invoice_num,s_date,c_id,c_name,total_items,grand_total,cashier_name FROM sales ORDER BY invoice_num ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "sales");
            //sales_table.DataSource = ds.Tables["sales"];
            MySqlCommand cmd = new MySqlCommand("SELECT stitched_id,pur_date,t_name,p_code,sub_name,per_gaj,items,quantity,unit_price FROM stitchedproduct ORDER BY stitched_id ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                sales_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            sales_table.DataSource = dta;
            sales_table.Columns[0].HeaderText = "ID";
            sales_table.Columns[1].HeaderText = "Date";
            sales_table.Columns[2].HeaderText = "Taylor";
            sales_table.Columns[3].HeaderText = "Code";
            sales_table.Columns[4].HeaderText = "Sub Name";

            sales_table.Columns[5].HeaderText = "Gaj";
            sales_table.Columns[6].HeaderText = "Items";
            sales_table.Columns[7].HeaderText = "Quantity";
            sales_table.Columns[8].HeaderText = "Sale Price";

            sales_table.Columns[0].Width = 40;
            sales_table.Columns[1].Width = 50;
            sales_table.Columns[2].Width = 50;
            sales_table.Columns[3].Width = 60;
            sales_table.Columns[4].Width = 80;
            sales_table.Columns[5].Width = 60;
            sales_table.Columns[6].Width = 80;
            sales_table.Columns[7].Width = 80;
            sales_table.Columns[8].Width = 80;

            //sales_table.Columns[6].DefaultCellStyle.Format = "N2";
            sales_table.Columns[8].DefaultCellStyle.Format = "N2";
        }

        private void txt_search_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("t_name LIKE '%" + txt_search.Text.ToString() + "%' OR sub_name LIKE '%" + txt_search.Text.ToString() + "%' "); //OR p_unit '%{1}%'
            sales_table.DataSource = dv;
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search";
            }
        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search")
            {
                txt_search.Text = "";
            }
        }
    }
}
