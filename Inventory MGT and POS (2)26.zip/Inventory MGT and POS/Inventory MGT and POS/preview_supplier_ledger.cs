﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class preview_supplier_ledger : Form
    {
        private MySqlConnection con;
        DataTable dt = new DataTable();
        public preview_supplier_ledger()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void preview_supplier_ledger_Load(object sender, EventArgs e)
        {
            load_ledger();
        }
        private void load_ledger()
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
        
                prm[0] = new MySqlParameter("spid", MySqlDbType.VarChar);
                prm[0].Value = txt_id.Text;

                prm[1] = new MySqlParameter("supname", MySqlDbType.VarChar);
                prm[1].Value = txt_name.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "load_sup_ledger";
                cmnd.Parameters.AddRange(prm);

                con.Open();
                MySqlDataReader sdr = cmnd.ExecuteReader();
                dt.Load(sdr);
                table_supledger.DataSource = dt;
                dt.Dispose();
                sdr.Dispose();
                cmnd.Dispose();


                table_supledger.Columns[0].HeaderText = "Ledger ID";
                table_supledger.Columns[1].HeaderText = "Supplier ID";
                table_supledger.Columns[2].HeaderText = "Date";
                table_supledger.Columns[3].HeaderText = "Supplier Name";

                table_supledger.Columns[4].HeaderText = "Credit";
                table_supledger.Columns[5].HeaderText = "Debit";
                table_supledger.Columns[6].HeaderText = "Remaining Balance";
                table_supledger.Columns[7].HeaderText = "Description";

                table_supledger.Columns[0].Width = 50;
                table_supledger.Columns[1].Width = 50;
                table_supledger.Columns[2].Width = 80;
                table_supledger.Columns[3].Width = 100;
                table_supledger.Columns[4].Width = 100;
                table_supledger.Columns[5].Width = 100;
                table_supledger.Columns[6].Width = 100;
                table_supledger.Columns[7].Width = 100;
            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}
