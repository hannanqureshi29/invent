﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class pay_tailor_balance : Form
    {
        private MySqlConnection con;
        public pay_tailor_balance(Dash dash)
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                decimal a = Convert.ToDecimal(txt_bln.Text);
                decimal b = Convert.ToDecimal(txt_amount_paid.Text);
                decimal c = a - b;

                con.Open();
                string query = ("UPDATE tailor set t_rmnblnc  = '" + c + "' WHERE t_id   = '" + txt_tid.Text + "' ;");
                MySqlCommand cmnd = new MySqlCommand(query, con);
                MySqlDataReader read;

                read = cmnd.ExecuteReader();


                read.Close();
                cmnd.Dispose();

                using (MySqlCommand cmd1 = new MySqlCommand("INSERT INTO tailor_ledger(t_id,t_name,date,t_credit,t_debit,t_balance)values(@tid,@tname,NOW(),@tcredit,@tdebit,@tbalance)", con))
                {
                    cmd1.Parameters.AddWithValue("@tid", Convert.ToInt64(txt_tid.Text));

                    cmd1.Parameters.AddWithValue("@tname", txt_name.Text);
                    cmd1.Parameters.AddWithValue("@tcredit", Convert.ToDouble(txt_amount_paid.Text));
                    cmd1.Parameters.AddWithValue("@tdebit", 0);
                    cmd1.Parameters.AddWithValue("@tbalance", c.ToString());
                    //cmd1.Parameters.AddWithValue("@description", "Sale Against Invoice Number:" + txt_invoice.Text);

                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();
                }


                con.Close();
                MessageBox.Show(c.ToString());
                Dash master = (Dash)Application.OpenForms["Dash"];
                master.btn_refresh.PerformClick();
                //if (Application.OpenForms.OfType<Dash>().Any())
                //{
                //    Dash master = (Dash)Application.OpenForms["Dash"];
                //    master.();
                //}
                //else
                //{

                //}
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Dash>().Any())
            {
                Dash master = (Dash)Application.OpenForms["Dash"];
                master.load_tailor_payable();
            }
            else
            {

            }
            this.Close();
        }

        private void pay_tailor_balance_Load(object sender, EventArgs e)
        {

        }
    }
}
