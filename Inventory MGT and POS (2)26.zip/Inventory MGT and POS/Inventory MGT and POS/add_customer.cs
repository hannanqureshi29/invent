﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class add_customer : Form
    {
        private MySqlConnection con;
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        MySqlCommand cmd;
        MySqlDataAdapter adapt;
        public add_customer()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_name.Text != "" || txt_name.Text == "Customer Name")
                {
                    cmd = new MySqlCommand("insert into customer(c_name,c_phone,c_email,c_adress,c_opnblnc,c_rmnblnc) values(@name,@phone,@email,@adress,@opnblnc,@rmnblnc)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@name", txt_name.Text);
                    cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
                    cmd.Parameters.AddWithValue("@email", txt_email.Text);
                    cmd.Parameters.AddWithValue("@adress", txt_adress.Text);
                    cmd.Parameters.AddWithValue("@opnblnc", txt_opnblnc.Text);
                    cmd.Parameters.AddWithValue("@rmnblnc", txt_rmnblnc.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Inserted Successfully");

                    //load_customers();
                }
                else
                {
                    MessageBox.Show("Please Enter Customer Name");
                }
                txt_name.Clear();
                txt_phone.Clear();
                txt_email.Clear();
                txt_adress.Clear();
                txt_opnblnc.Clear();
                txt_rmnblnc.Clear();

                if (Application.OpenForms.OfType<POS>().Any())
                {
                    POS master = (POS)Application.OpenForms["POS"];
                    master.customer_name_search();
                }
                else
                {

                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
