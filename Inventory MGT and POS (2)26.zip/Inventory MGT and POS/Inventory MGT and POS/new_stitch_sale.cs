﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class new_stitch_sale : Form
    {
        private MySqlConnection con;
        public new_stitch_sale()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void txt_pname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_code,type,category FROM stitchedproduct WHERE p_name = '" + txt_pname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_item_code.Text = dr.GetValue(0).ToString();
                    txt_type.Text = dr.GetValue(1).ToString();
                    txt_pcat.Text = dr.GetValue(2).ToString();


                }
                con.Close();
            }
        }
        private void p_code_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_code FROM stitchedproduct", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_item_code.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void new_stitch_sale_Load(object sender, EventArgs e)
        {
            p_code_search();
            label5.Text = Login.u_name;
            product_name_search();
            size_search();
            max_invoice_id();
            tailor_name_search();
        }
        private void max_invoice_id()
        {
            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(invoice_num)+1 FROM add_new_stitchedproduct ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txt_invoice.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }
        private void product_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_name FROM stitchedproduct", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_pname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        private void size_search()
        {
            //MySqlCommand cmd = new MySqlCommand("SELECT size FROM stitchedproduct", con);
            //con.Open();
            //MySqlDataReader reader = cmd.ExecuteReader();
            //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            //while (reader.Read())
            //{
            //    MyCollection.Add(reader.GetString(0));
            //}
            //txt_size.AutoCompleteCustomSource = MyCollection;
            //con.Close();
        }

        private void txt_size_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT quantity,unit_price FROM stitchedproduct WHERE size = '" + txt_size.Text + "' AND p_name ='" + txt_pname.Text + "' AND p_code = '" + txt_item_code.Text + "' ORDER BY COUNT(DISTINCT stitched_id) ", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_stock.Text = dr.GetValue(0).ToString();
                    txt_unitprice.Text = dr.GetValue(1).ToString();


                }
                con.Close();
            }
        }

        private void txt_qty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                int u_stock;
                int old_stock = Convert.ToInt32(txt_stock.Text);
                int new_stock = Convert.ToInt32(txt_qty.Text);

                u_stock = old_stock + new_stock;
                string[] row1 = { txt_stock.Text, u_stock.ToString() };
                hidden_table.Rows.Add(row1);

                string[] row = { txt_item_code.Text, txt_pname.Text, txt_type.Text, txt_pcat.Text, txt_size.Text, txt_qty.Text, u_stock.ToString(), txt_unitprice.Text, txt_ptotal.Text };
                TableProducts.Rows.Add(row);

                Double sum = 0;
                for (int i = 0; i < TableProducts.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(TableProducts.Rows[i].Cells[7].Value);
                }
                label7.Text = (TableProducts.RowCount).ToString();
                txt_grand_total.Text = sum.ToString("N2");
                //For Tax Amount Calculation with respect to 17% 
                //label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
                // label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

                txt_item_code.Clear();
                txt_pname.Clear();
                txt_type.Clear();
                txt_pcat.Clear();
                txt_type.Clear();
                txt_stock.Clear();
                txt_unitprice.Clear();
                txt_qty.Clear();
                txt_ptotal.Clear();
                // txt_pdesc.Clear();
            }
        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_qty.Text.Trim() != string.Empty)
                {
                    Double A = Convert.ToDouble(txt_unitprice.Text);
                    Double B = Convert.ToDouble(txt_qty.Text);
                    txt_ptotal.Text = (A * B).ToString("N2");
                }
                else if (txt_qty.Text.Trim() == string.Empty)
                {
                    txt_ptotal.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                for (int i = 0; i < TableProducts.Rows.Count; i++)
                {
                    using (MySqlCommand cmd = new MySqlCommand("INSERT INTO add_new_stitchedproduct(invoice_num,s_date,t_id,t_name,p_name,p_code,type,category,size,quantity,unit_price,total,total_items,grand_total,cash_recieved,change_cash,cashier_name)values(@invoicenum,NOW(),@tid,@tname,@pname,@pcode,@type,@cat,@size,@quantity,@unitprice,@total,@totalitems,@grandtotal,@cashrecieved,@changecash,@cashier)", con))
                    {
                        cmd.Parameters.AddWithValue("@invoicenum", txt_invoice.Text);

                        cmd.Parameters.AddWithValue("@tid", Convert.ToInt64(txt_id.Text));
                        cmd.Parameters.AddWithValue("@tname", comb_cname.Text);


                        cmd.Parameters.AddWithValue("@pcode", Convert.ToInt32(TableProducts.Rows[i].Cells[0].Value));
                        cmd.Parameters.AddWithValue("@pname", TableProducts.Rows[i].Cells[1].Value.ToString());
                        cmd.Parameters.AddWithValue("@type", TableProducts.Rows[i].Cells[2].Value.ToString());
                        cmd.Parameters.AddWithValue("@cat", TableProducts.Rows[i].Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@size", TableProducts.Rows[i].Cells[4].Value.ToString());
                        // cmd.Parameters.AddWithValue("@tot_items", Convert.ToInt32(label7.Text));

                        cmd.Parameters.AddWithValue("@quantity", Convert.ToDouble(TableProducts.Rows[i].Cells[5].Value));
                        cmd.Parameters.AddWithValue("@unitprice", Convert.ToInt32(TableProducts.Rows[i].Cells[7].Value));
                        cmd.Parameters.AddWithValue("@total", Convert.ToDouble(TableProducts.Rows[i].Cells[8].Value));
                        cmd.Parameters.AddWithValue("@totalitems", Convert.ToInt32(label7.Text));
                        // cmd.Parameters.AddWithValue("@subtotal", Convert.ToDouble(label9.Text));
                        // cmd.Parameters.AddWithValue("@taxamount", Convert.ToDouble(label11.Text));
                        cmd.Parameters.AddWithValue("@grandtotal", Convert.ToDouble(txt_grand_total.Text));
                        cmd.Parameters.AddWithValue("@cashrecieved", Convert.ToDouble(txt_cash_rec.Text));
                        cmd.Parameters.AddWithValue("@changecash", Convert.ToDouble(txt_change.Text));
                        cmd.Parameters.AddWithValue("@cashier", label5.Text.ToString());
                        // con.Open();
                        cmd.ExecuteNonQuery();
                        // con.Close();
                        cmd.Dispose();
                    }
                }
                for (int i = 0; i < TableProducts.Rows.Count; i++)
                {

                    string query = ("UPDATE stitchedproduct set quantity ='" + TableProducts.Rows[i].Cells[6].Value + "' WHERE p_code = '" + TableProducts.Rows[i].Cells[0].Value + "' ;");
                    MySqlCommand cmnd = new MySqlCommand(query, con);
                    MySqlDataReader read;

                    read = cmnd.ExecuteReader();
                    // 
                    read.Close();
                    cmnd.Dispose();
                }


                con.Close();
                MessageBox.Show("Success");
                ////For Printing Receipt
                //printPreviewDialog1.Document = printDocument1;
                //printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 285, 600);
                //printPreviewDialog1.ShowDialog();
                //  TableProducts.AllowUserToAddRows = false;
                //Reload Page after one entry
                max_invoice_id();
                //emptycart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }
        public void tailor_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT t_name FROM tailor", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            comb_cname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void comb_cname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT t_id FROM tailor WHERE t_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    // txt_phone.Text = dr.GetValue(0).ToString();
                    txt_id.Text = dr.GetValue(0).ToString();
                }
                con.Close();
            }
        }

        private void txt_cash_rec_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_change.Text = (Convert.ToDouble(txt_cash_rec.Text) - Convert.ToDouble(txt_grand_total.Text)).ToString("N2");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (Application.OpenForms.OfType<addnew_tailor>().Any())
            //{
            //    Application.OpenForms.OfType<addnew_tailor>().First().BringToFront();
            //}
            //else
            //{
            //    var dash = new addnew_tailor();
            //    dash.Show();

            //}
        }

        private void txt_item_code_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_name,type,category,size,quantity,unit_price FROM stitchedproduct WHERE p_code = '" + txt_item_code.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_pname.Text = dr.GetValue(0).ToString();
                    txt_type.Text = dr.GetValue(1).ToString();
                    txt_pcat.Text = dr.GetValue(2).ToString();

                    txt_size.Text = dr.GetValue(3).ToString();
                    txt_stock.Text = dr.GetValue(4).ToString();
                    txt_unitprice.Text = dr.GetValue(5).ToString();


                }
                con.Close();
            }
        }
    }
}
