﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace Inventory_MGT_and_POS
{
    public partial class Login : Form
    {

        // public static string type;
        private MySqlConnection con;
        public static string u_name;
        //SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");

        public Login()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (txt_UserName.Text == "Username")
            {
                txt_UserName.Text = "";
                txt_UserName.ForeColor = Color.White;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_UserName.Text))
            {
                txt_UserName.Text = "Username";
                txt_UserName.ForeColor = Color.LightGray;
            }
        }
        static string Encrypt(string value)
        {
            //Using MD5 to encrypt a string
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                //Hash data
                byte[] data = md5.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(data);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_UserName.Text) || string.IsNullOrEmpty(txt_Password.Text))
            {
                MessageBox.Show("Please input Username and Password", "Error");
            }
            else
            {
                try
                {
                    con.Open();
                    MySqlDataAdapter sda = new MySqlDataAdapter("SELECT COUNT(*) FROM users WHERE u_name = '" + txt_UserName.Text + "' AND 	u_pass = '" + Encrypt(txt_Password.Text) + "' ", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        u_name = txt_UserName.Text;
                        string Query = "UPDATE users SET last_login = Now() WHERE u_name = '" + txt_UserName.Text + "';";
                        MySqlCommand cmd2 = new MySqlCommand(Query, con);
                        MySqlCommand commandDatabase = cmd2;
                        MySqlDataReader myReader = commandDatabase.ExecuteReader();
                        this.Hide();
                        var dash = new Main();
                        dash.Show();
                        //new Main().Show();
                        //if (myReader.HasRows)
                        //{
                        //    myReader.Read();
                        //    if(myReader[3].ToString()=="Admin")
                        //    {
                        //        Login.type = "A";
                        //    }
                        //    else if(myReader[3].ToString() == "User")
                        //    {
                        //        Login.type = "U";
                        //    }

                        //    Main dash = new Main();
                        //    dash.Show();
                        //    this.Hide();

                        //}

                    }
                    else
                    {
                        MessageBox.Show("Incorrect Username or Password");
                    }

                }


                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }

            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (txt_Password.Text == "Password")
            {
                txt_Password.Text = "";
                txt_Password.ForeColor = Color.White;
                txt_Password.UseSystemPasswordChar = true;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_Password.Text))
            {
                txt_Password.Text = "Password";
                txt_Password.ForeColor = Color.LightGray;
                txt_Password.UseSystemPasswordChar = false;
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void txt_Password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(txt_UserName.Text) || string.IsNullOrEmpty(txt_Password.Text))
                {
                    MessageBox.Show("Please input Username and Password", "Error");
                }
                else
                {
                    try
                    {
                        con.Open();
                        MySqlDataAdapter sda = new MySqlDataAdapter("SELECT COUNT(*) FROM users WHERE u_name = '" + txt_UserName.Text + "' AND u_pass = '" + Encrypt(txt_Password.Text) + "' ", con);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        if (dt.Rows[0][0].ToString() == "1")
                        {
                            u_name = txt_UserName.Text;
                            string Query = "UPDATE users SET last_login = Now() WHERE u_name = '" + txt_UserName.Text + "';";
                            MySqlCommand cmd2 = new MySqlCommand(Query, con);
                            MySqlCommand commandDatabase = cmd2;
                            MySqlDataReader myReader = commandDatabase.ExecuteReader();
                            this.Hide();
                            var dash = new Main();
                            dash.Show();

                        }
                        else
                        {
                            MessageBox.Show("Incorrect Username or Password");
                        }
                    }
                    catch (Exception ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
