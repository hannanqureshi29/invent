﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Runtime.InteropServices;

namespace Inventory_MGT_and_POS
{

    public partial class preview_purchase : Form
    {
        private MySqlConnection con;
        DataTable dt = new DataTable();
        public preview_purchase()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void preview_purchase_Load(object sender, EventArgs e)
        {
            load_from_sale();
            supplier_balnce();
        }
        public void supplier_balnce()
        {
            if (txt_balance != null)
            {
                try
                {
                    con.Open();
                    MySqlCommand cmnd = new MySqlCommand("SELECT sp_rmnblnc FROM suppliers WHERE sp_id = '" + txt_sid.Text + "'", con);
                    Object temp = cmnd.ExecuteScalar();
                    txt_balance.Text = temp.ToString();
                    con.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }

        }
        private void load_from_sale()
        {
            try
            {
                MySqlParameter[] pms = new MySqlParameter[2];
                //pms[0] = new MySqlParameter("cid", MySqlDbType.Int32);
                //pms[0].Value = txt_cid.Text;
                pms[0] = new MySqlParameter("spid", MySqlDbType.VarChar);
                pms[0].Value = txt_sid.Text;
                pms[1] = new MySqlParameter("invoicenum", MySqlDbType.VarChar);
                pms[1].Value = lbl_invoice_num.Text;

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "load_from_purchase";
                cmd.Parameters.AddRange(pms);

                con.Open();
                using (MySqlDataReader read = cmd.ExecuteReader())

                {
                    if (read.Read())
                    {
                        txt_name.Text = (read["cname"]).ToString();
                        // txt_cbalance.Text = (read["crmnblnc"]).ToString();
                        // lbl_invoice_num.Text = (read["invoicenum"]).ToString();
                        label7.Text = (read["totalitems"]).ToString();
                        // label9.Text = (read["subtotal"]).ToString();
                        //label11.Text = (read["taxamount"]).ToString();
                        txt_grand_total.Text = (read["grandtotal"]).ToString();
                        txt_cash_rec.Text = (read["amountreceived"]).ToString();

                        txt_change.Text = (read["changereturned"]).ToString();
                        //   txt_cash_rec.Text = (read["cbalance"]).ToString();

                    }
                }
                cmd.Dispose();


                MySqlParameter[] prm = new MySqlParameter[2];

                prm[0] = new MySqlParameter("spid", MySqlDbType.VarChar);
                prm[0].Value = txt_sid.Text;
                prm[1] = new MySqlParameter("invoicenum", MySqlDbType.VarChar);
                prm[1].Value = lbl_invoice_num.Text;
                //prm[1] = new MySqlParameter("qupdsta", MySqlDbType.VarChar);
                //prm[1].Value = txt_Update_Status.Text;
                //prm[2] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                //prm[2].Value = txt_Rev_Sta.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "POP_table";
                cmnd.Parameters.AddRange(prm);

                MySqlDataReader sdr = cmnd.ExecuteReader();
                dt.Load(sdr);
                purchase_record_table.DataSource = dt;
                dt.Dispose();
                sdr.Dispose();
                cmnd.Dispose();



                purchase_record_table.Columns[0].HeaderText = "Code";
                purchase_record_table.Columns[1].HeaderText = "Product Name";
                purchase_record_table.Columns[2].HeaderText = "Category";
                purchase_record_table.Columns[3].HeaderText = "Product Description";
                purchase_record_table.Columns[4].HeaderText = "Unit Price";
                purchase_record_table.Columns[5].HeaderText = "QTY";
                purchase_record_table.Columns[6].HeaderText = "Total%";
                //Products_Table.Columns[7].HeaderText = "Unit Price";
                //Products_Table.Columns[8].HeaderText = "Total";


                purchase_record_table.Columns[0].Width = 50;
                purchase_record_table.Columns[1].Width = 150;
                purchase_record_table.Columns[2].Width = 200;
                purchase_record_table.Columns[3].Width = 100;
                purchase_record_table.Columns[4].Width = 100;
                purchase_record_table.Columns[5].Width = 50;
                purchase_record_table.Columns[6].Width = 100;



            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void preview_purchase_MouseDown(object sender, MouseEventArgs e)
        {
            //    ReleaseCapture();
            //    SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}
