﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Inventory_MGT_and_POS
{
    public partial class customerledger : Form
    {
        DataTable dta;
        private MySqlConnection con;
        public customerledger()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void customerledger_Load(object sender, EventArgs e)
        {
            loadledger();
        }
        public void loadledger()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT c_id,cus_name,cus_balance FROM customer_ledger GROUP BY c_id  ", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                table_cusledger.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            table_cusledger.DataSource = dta;
            table_cusledger.Columns[0].HeaderText = "Customer ID";
            table_cusledger.Columns[1].HeaderText = "Customer Name";
            table_cusledger.Columns[2].HeaderText = "Customer Bal";
            //table_cusledger.Columns[3].HeaderText = "Customer Name";
            //table_cusledger.Columns[4].HeaderText = "Credit";

            //table_cusledger.Columns[5].HeaderText = "Debit";
            //table_cusledger.Columns[6].HeaderText = "Customer Bal";
            //table_cusledger.Columns[7].HeaderText = "Description";
            // sales_table.Columns[8].HeaderText = "Sale Price";

            table_cusledger.Columns[0].Width = 300;
            table_cusledger.Columns[1].Width = 300;
            table_cusledger.Columns[2].Width = 300;
            //table_cusledger.Columns[3].Width = 60;
            //table_cusledger.Columns[4].Width = 80;
            //table_cusledger.Columns[5].Width = 60;
            //table_cusledger.Columns[6].Width = 80;
            //table_cusledger.Columns[7].Width = 80;
            //table_cusledger.Columns[8].Width = 80;
        }

        private void txt_search_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("cus_name LIKE '%" + txt_search.Text.ToString() + "%' "); //OR p_unit '%{1}%'
            table_cusledger.DataSource = dv;
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search";
            }
        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search")
            {
                txt_search.Text = "";
            }
        }

        private void table_cusledger_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            preview_customer_ledg edt = new preview_customer_ledg();
            int row = table_cusledger.CurrentRow.Index;

            // edt.txt_id.Text = Convert.ToString(products_table[0, row].Value);
            edt.txt_id.Text = Convert.ToString(table_cusledger[0, row].Value);
            edt.txt_name.Text = Convert.ToString(table_cusledger[1, row].Value);

            
            // edt.txt_pcode.Text = Convert.ToString(products_table[1, row].Value);
            edt.Show();
        }
    }
}
