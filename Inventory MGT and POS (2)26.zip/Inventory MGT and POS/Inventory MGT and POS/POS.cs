﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class POS : Form
    {
        private MySqlConnection con;
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-1SK7EUJ\\SQLEXPRESS01;Initial Catalog=pos;Integrated Security=True");
        public POS()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void search_product()
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //if (textBox4.Text.Trim() == string.Empty)
            //{
            //    textBox4.Text = "0";
            //}
            //Double A = Convert.ToDouble(textBox4.Text);
            //Double B = Convert.ToDouble(textBox5.Text);
            //textBox6.Text = (A * B).ToString("N2");
        }
        private void product_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT p_name FROM products", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_pname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        public void customer_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT c_name FROM customer", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            comb_cname.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }
        private void max_invoice_id()
        {
            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(invoice_num)+1 FROM sales ", con))
            {
                cmd.CommandType = CommandType.Text;
                con.Open();
                txt_invoice.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
        }
        private void POS_Load(object sender, EventArgs e)
        {
            label5.Text = Login.u_name;
            this.ActiveControl = txt_pname;
            max_invoice_id();
            // product_name_search();
            supplier_name_search();
            customer_name_search();
            TableProducts.Columns[0].Width = 50;
            TableProducts.Columns[1].Width = 100;
            // TableProducts.Columns[2].Width = 100;
            TableProducts.Columns[2].Width = 150;
            TableProducts.Columns[3].Width = 80;
            TableProducts.Columns[4].Width = 40;
            TableProducts.Columns[5].Width = 100;

            //DataGridViewRow row = (DataGridViewRow)TableProducts.Rows[0].Clone();
            //row.Cells[0].Value = 123;
            //row.Cells[1].Value = "National Masala";
            //row.Cells[2].Value = "Grocery";
            //row.Cells[3].Value = "National Masala 250grams";
            //row.Cells[4].Value = 80;
            //row.Cells[5].Value = 2;
            //row.Cells[6].Value = 160;
            //TableProducts.Rows.Add(row);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
            TextBox txtDecimal = sender as TextBox;
            if (e.KeyChar == '.' && txtDecimal.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
            TextBox txtDecimal = sender as TextBox;
            if (e.KeyChar == '.' && txtDecimal.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txt_qty.Text.Trim() != string.Empty)
                {
                    Double A = Convert.ToDouble(txt_unitprice.Text);
                    Double B = Convert.ToDouble(txt_qty.Text);
                    txt_ptotal.Text = (A * B).ToString("N2");
                }
                else if (txt_qty.Text.Trim() == string.Empty)
                {
                    txt_ptotal.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void TableProducts_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                double u_stock;
                double old_stock = Convert.ToDouble(txt_stock.Text);
                double new_stock = Convert.ToDouble(txt_qty.Text);

                u_stock = old_stock - new_stock;
                string[] row1 = { txt_stock.Text, u_stock.ToString() };
                hidden_table.Rows.Add(row1);

                string[] row = { txt_item_code.Text, txt_pname.Text, txt_pdesc.Text, txt_unitprice.Text, txt_qty.Text, txt_ptotal.Text };
                TableProducts.Rows.Add(row);

                Double sum = 0;
                for (int i = 0; i < TableProducts.Rows.Count; ++i)
                {
                    sum += Convert.ToDouble(TableProducts.Rows[i].Cells[5].Value);
                }
                label7.Text = (TableProducts.RowCount).ToString();
                txt_grand_total.Text = sum.ToString("N2");
                //For Tax Amount Calculation with respect to 17% 
                //label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
                // label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

                txt_item_code.Clear();
                txt_pname.Clear();
                txt_pcat.Clear();
                txt_stock.Clear();
                txt_unitprice.Clear();
                txt_qty.Clear();
                txt_ptotal.Clear();
                txt_pdesc.Clear();
            }

        }

        private void TableProducts_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //label9.Text = CellSum().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                for (int i = 0; i < TableProducts.Rows.Count; i++)
                {
                    using (MySqlCommand cmd = new MySqlCommand("INSERT INTO sales(invoice_num,s_date,c_id,c_name,c_rmnblnc,s_phone,p_name,p_code,p_desc,p_saleprice,total_items,p_qty,total,grand_total,amount_received,change_returned,cashier_name)values(@inv_num,NOW(),@c_id,@c_name,@c_blnc,@sphone,@pname,@p_code,@pdesc,@sale_price,@tot_items,@qty,@item_total,@grand_total,@amnt_rcv,@chng_rtrn,@cashier)", con))
                    {
                        cmd.Parameters.AddWithValue("@inv_num", txt_invoice.Text);
                        // cmd.Parameters.AddWithValue("@date", System.DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@c_id", Convert.ToInt64(txt_cid.Text));
                        cmd.Parameters.AddWithValue("@c_name", comb_cname.Text);
                        cmd.Parameters.AddWithValue("@c_blnc", txt_cbalance.Text);
                        cmd.Parameters.AddWithValue("@sphone", txt_phone.Text);
                        //cmd.Parameters.AddWithValue("@pid", Convert.ToInt64(textBox15.Text));
                        cmd.Parameters.AddWithValue("@p_code", Convert.ToString(TableProducts.Rows[i].Cells[0].Value));
                        cmd.Parameters.AddWithValue("@pname", TableProducts.Rows[i].Cells[1].Value.ToString());

                        // cmd.Parameters.AddWithValue("@cat", TableProducts.Rows[i].Cells[2].Value.ToString());
                        cmd.Parameters.AddWithValue("@pdesc", TableProducts.Rows[i].Cells[2].Value.ToString());

                        cmd.Parameters.AddWithValue("@sale_price", Convert.ToInt32(TableProducts.Rows[i].Cells[3].Value));
                        cmd.Parameters.AddWithValue("@tot_items", Convert.ToInt32(label7.Text));
                        cmd.Parameters.AddWithValue("@qty", Convert.ToDouble(TableProducts.Rows[i].Cells[4].Value));
                        cmd.Parameters.AddWithValue("@item_total", Convert.ToDouble(TableProducts.Rows[i].Cells[5].Value));
                        // cmd.Parameters.AddWithValue("@subtotal", Convert.ToDouble(label9.Text));
                        // cmd.Parameters.AddWithValue("@taxamount", Convert.ToDouble(label11.Text));
                        cmd.Parameters.AddWithValue("@grand_total", Convert.ToDouble(txt_grand_total.Text));
                        cmd.Parameters.AddWithValue("@amnt_rcv", Convert.ToDouble(txt_cash_rec.Text));
                        cmd.Parameters.AddWithValue("@chng_rtrn", Convert.ToDouble(txt_change.Text));
                        cmd.Parameters.AddWithValue("@cashier", label5.Text.ToString());
                        // con.Open();
                        cmd.ExecuteNonQuery();
                        // con.Close();
                        cmd.Dispose();
                    }
                }
                for (int i = 0; i < TableProducts.Rows.Count; i++)
                {

                    string query = ("UPDATE products set total_gaj ='" + hidden_table.Rows[i].Cells[1].Value + "' WHERE p_code = '" + TableProducts.Rows[i].Cells[0].Value + "' ;");
                    MySqlCommand cmnd = new MySqlCommand(query, con);
                    MySqlDataReader read;

                    read = cmnd.ExecuteReader();
                    // 
                    read.Close();
                    cmnd.Dispose();
                }

                
                    using (MySqlCommand cmd1 = new MySqlCommand("INSERT INTO customer_ledger(c_id,cus_name,date,cus_credit,cus_debit,cus_balance,description)values(@cid,@cusname,NOW(),@cuscredit,@cusdebit,@cusbalance,@description)", con))
                    {
                        cmd1.Parameters.AddWithValue("@cid", Convert.ToInt64(txt_cid.Text));

                        cmd1.Parameters.AddWithValue("@cusname", comb_cname.Text);
                    cmd1.Parameters.AddWithValue("@cuscredit", Convert.ToDouble(txt_grand_total.Text));
                    cmd1.Parameters.AddWithValue("@cusdebit", Convert.ToDouble(txt_cash_rec.Text));
                        cmd1.Parameters.AddWithValue("@cusbalance", txt_bal.Text);
                        cmd1.Parameters.AddWithValue("@description", "Sale Against Invoice Number:" + txt_invoice.Text);

                        cmd1.ExecuteNonQuery();
                        cmd1.Dispose();
                    }
                
                double a = Convert.ToDouble(txt_change.Text);

                if (a < 0)
                {
                    double b = Convert.ToDouble(txt_bal.Text);
                   // double c = b - a;
                    string query = ("UPDATE customer SET c_rmnblnc ='" + b.ToString() + "' WHERE c_id  = '" + txt_cid.Text + "' ;");
                    MySqlCommand cmnd1 = new MySqlCommand(query, con);
                    MySqlDataReader read1;
                    // MessageBox.Show("test");
                    read1 = cmnd1.ExecuteReader();
                    read1.Close();
                    cmnd1.Dispose();
                }

                con.Close();
                MessageBox.Show("Success");
                ////For Printing Receipt
                //printPreviewDialog1.Document = printDocument1;
                //printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 285, 600);
                //printPreviewDialog1.ShowDialog();
                //  TableProducts.AllowUserToAddRows = false;
                //Reload Page after one entry
                max_invoice_id();
                emptycart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
            //For Saving Values in Database-Sales Table



        }

        private void emptycart()
        {
            txt_item_code.Clear();
            txt_pname.Clear();
            txt_pcat.Clear();
            txt_stock.Clear();
            txt_unitprice.Clear();
            txt_qty.Clear();
            txt_ptotal.Clear();
            txt_pdesc.Clear();
            txt_cid.Clear();

            comb_cname.ResetText();
            txt_cbalance.Clear();
            txt_phone.Clear();

            TableProducts.Rows.Clear();
            TableProducts.Refresh();
            txt_invoice.Refresh();

            hidden_table.Rows.Clear();
            hidden_table.Refresh();

            label7.Text = "0";
            label9.Text = "0";
            label11.Text = "0";

            txt_grand_total.Text ="0";
            txt_grand_total.Refresh();
            txt_cash_rec.Text = "0";
            //txt_change.Clear();
            txt_bal.Text = "0";
            txt_change.Text ="0";
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("Naveed Super Store", new Font("Arial", 14), Brushes.Black, new Point(50, 10));
            e.Graphics.DrawString("120 A, Commercial Area, Samnabad, Lahore", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(30, 35));
            e.Graphics.DrawString("Phone # 04237895541 - 03002211445", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(50, 50));
            e.Graphics.DrawString("______________________________________________", new Font("Arial", 8), Brushes.Black, new Point(0, 60));
            e.Graphics.DrawString((System.DateTime.Now.ToString("dd/MM/yyyy h:mm tt")), new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(5, 75));
            e.Graphics.DrawString("Invoice # :" + txt_invoice.Text, new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(180, 75));
            e.Graphics.DrawString("-----------------------------------------------------------------------------", new Font("Arial", 8), Brushes.Black, new Point(0, 85));
            e.Graphics.DrawString("Customer:" + comb_cname.Text.Trim(), new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(5, 95));
            e.Graphics.DrawString("Cashier:" + label5.Text.Trim(), new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(180, 95));
            e.Graphics.DrawString("-----------------------------------------------------------------------------", new Font("Arial", 8), Brushes.Black, new Point(0, 105));
            e.Graphics.DrawString("Items", new Font("Arial", 8), Brushes.Black, new Point(5, 115));
            e.Graphics.DrawString("Unit Price", new Font("Arial", 8), Brushes.Black, new Point(140, 115));
            e.Graphics.DrawString("QTY", new Font("Arial", 8), Brushes.Black, new Point(195, 115));
            e.Graphics.DrawString("Total", new Font("Arial", 8), Brushes.Black, new Point(230, 115));

            //For Printing Contents of Datagridview
            int line = 130;
            foreach (DataGridViewRow row in TableProducts.Rows)
            {
                int space = 5;
                int counter = 0;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    string text = "";
                    if (counter == 1 || counter == 4 || counter == 5 || counter == 6)
                    {
                        if (cell.Value != null)
                        {
                            text = cell.Value.ToString();
                        }
                        e.Graphics.DrawString(text, new Font("Arial", 7), Brushes.Black, space, line);

                        if (counter == 5)
                        {
                            space = space + 22;
                        }
                        else if (counter == 4)
                        {
                            space = space + 50;
                        }
                        else
                        {
                            space = space + 150;
                        }
                    }
                    counter = counter + 1;
                }
                line = line + 12;
            }

            e.Graphics.DrawString("Total # of Items:                                              " + label7.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 455));
            e.Graphics.DrawString("Sub Total:                                                     " + label9.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 470));
            e.Graphics.DrawString("GST Amount @17%:                                    " + label11.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 485));
            e.Graphics.DrawString("Grand Total:                                                " + Convert.ToString(txt_grand_total.Text).Trim(), new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(10, 500));
            e.Graphics.DrawString("Cash Received:                                            " + Convert.ToString(txt_cash_rec.Text).Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 515));
            e.Graphics.DrawString("Change:                                                        " + Convert.ToString(txt_change.Text).Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 530));
            e.Graphics.DrawString("Thank You for Shopping ! Please visit us again.", new Font("Century Gothic", 7), Brushes.Black, new Point(25, 550));
            e.Graphics.DrawString("Software Developed By Waleed Ahmad", new Font("Century Gothic", 7), Brushes.Black, new Point(40, 570));
            e.Graphics.DrawString("iamwaleedahmad@gmail.com | 03004481794", new Font("Century Gothic", 7), Brushes.Black, new Point(28, 580));
        }

        private void textBox12_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_change.Text = (Convert.ToDouble(txt_cash_rec.Text) - Convert.ToDouble(txt_grand_total.Text)).ToString("N2");
                

            }
            

            
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    MySqlCommand cmd = new MySqlCommand("SELECT p_code,p_cat,p_desc,total_gaj FROM products WHERE p_name = '" + txt_pname.Text + "'", con);
            //    con.Open();
            //    MySqlDataReader dr = cmd.ExecuteReader();
            //    while (dr.Read())
            //    {
            //        txt_item_code.Text = dr.GetValue(0).ToString();
            //        txt_pcat.Text = dr.GetValue(1).ToString();
            //        txt_pdesc.Text = dr.GetValue(2).ToString();
            //        txt_stock.Text = dr.GetValue(3).ToString();
            //      //  txt_unitprice.Text = dr.GetValue(4).ToString();

            //    }
            //    con.Close();
            //}
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT p_name,total_gaj,p_desc,per_gaj FROM products WHERE p_code = '" + txt_item_code.Text + "' AND supplier_name ='" + txt_pcat.Text + "' ", con); //ORDER BY COUNT(DISTINCT p_id )
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_pname.Text = dr.GetValue(0).ToString();
                    // txt_pcat.Text = dr.GetValue(1).ToString();
                    txt_stock.Text = dr.GetValue(1).ToString();
                    txt_pdesc.Text = dr.GetValue(2).ToString();
                    txt_pergaj.Text = dr.GetValue(3).ToString();
                    // txt_unitprice.Text = dr.GetValue(3).ToString();
                }
                con.Close();
            }
        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT c_id,c_rmnblnc,c_phone FROM customer WHERE c_name = '" + comb_cname.Text + "'", con);
                con.Open();
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_cid.Text = dr.GetValue(0).ToString();
                    txt_cbalance.Text = dr.GetValue(1).ToString();
                    txt_phone.Text = dr.GetValue(2).ToString();
                }
                con.Close();
            }
            // this.ActiveControl = txt_pname;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
            //calculations();
        }
        private void calculations()
        {
            Double sum = 0;
            for (int i = 0; i < TableProducts.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(TableProducts.Rows[i].Cells[6].Value);
            }
            label7.Text = (TableProducts.RowCount).ToString();
            txt_grand_total.Text = sum.ToString("N2");
            //For Tax Amount Calculation with respect to 17% 
            label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
            label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");
        }

        private void TableProducts_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            calculations();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<add_customer>().Any())
            {
                Application.OpenForms.OfType<add_customer>().First().BringToFront();
            }
            else
            {
                var dash = new add_customer();
                dash.Show();

            }


        }


        private void POS_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.Q)
            {
                this.ActiveControl = txt_cash_rec;
            }
        }

        private void TableProducts_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in TableProducts.Rows)
                try
                {
                    double a;
                    a = Convert.ToDouble(row.Cells[TableProducts.Columns[4].Index].Value) * Convert.ToDouble(row.Cells[TableProducts.Columns[5].Index].Value);
                    row.Cells[TableProducts.Columns[6].Index].Value = a.ToString("N2");

                    Double sum = 0;
                    for (int i = 0; i < TableProducts.Rows.Count; ++i)
                    {
                        sum += Convert.ToDouble(TableProducts.Rows[i].Cells[6].Value);


                    }
                    label7.Text = (TableProducts.RowCount).ToString();
                    txt_grand_total.Text = sum.ToString();
                    label11.Text = (0.17 * Convert.ToDouble(sum)).ToString("N2");
                    label9.Text = (Convert.ToDouble(txt_grand_total.Text) - Convert.ToDouble(label11.Text)).ToString("N2");

                    for (int x = 0; x < hidden_table.Rows.Count; ++x)
                    {
                        int b;
                        b = Convert.ToInt32(hidden_table.Rows[x].Cells[0].Value) - Convert.ToInt32(TableProducts.Rows[x].Cells[5].Value);
                        hidden_table.Rows[x].Cells[1].Value = b;
                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

        }

        private void TableProducts_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //preview_sale edt = new preview_sale();
            //int row = TableProducts.CurrentRow.Index;
            //edt.txt_cid.Text = Convert.ToString(TableProducts[0, row].Value);
            ////edt.txt_Ref.Text = Convert.ToString(TableProducts[1, row].Value);
            ////edt.txt_Update_Status.Text = Convert.ToString(TableProducts[2, row].Value);
            ////edt.txt_Rev_Sta.Text = Convert.ToString(TableProducts[3, row].Value);
            //edt.Show();
        }

        private void comb_cname_Enter(object sender, EventArgs e)
        {

        }

        private void lblFecha_Click(object sender, EventArgs e)
        {

        }

        private void lblhora_Click(object sender, EventArgs e)
        {

        }
        public void supplier_name_search()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products", con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            while (reader.Read())
            {
                MyCollection.Add(reader.GetString(0));
            }
            txt_pcat.AutoCompleteCustomSource = MyCollection;
            con.Close();
        }

        private void txt_pcat_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // MySqlCommand cmd = new MySqlCommand("SELECT supplier_name FROM products WHERE supplier_name = '" + txt_pcat.Text + "'", con);
                // con.Open();

                MySqlCommand cmd1 = new MySqlCommand("SELECT p_code FROM products WHERE supplier_name = '" + txt_pcat.Text + "' AND total_gaj > 0", con);
                con.Open();
                MySqlDataReader reader = cmd1.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txt_item_code.AutoCompleteCustomSource = MyCollection;
                //con.Close();

                con.Close();
            }
        }

        private void txt_change_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(txt_cash_rec.Text) > Convert.ToDouble(txt_grand_total.Text))
                {
                    MessageBox.Show("Amount is Greater Than Total");
                    txt_cash_rec.Text = "0";
                    txt_change.Text = "0";
                    txt_bal.Text = "0";
                }

                if ((Convert.ToDouble(txt_change.Text) < 0)) //&& (String.IsNullOrWhiteSpace(txt_change.Text))
                {
                    double a = -1;
                    double b = Convert.ToDouble(txt_change.Text);
                    double c = a * b;
                    double d = Convert.ToDouble(txt_cbalance.Text);
                    double f = c + d;
                    txt_bal.Text = f.ToString();
                }

                if (Convert.ToDouble(txt_cash_rec.Text) == Convert.ToDouble(txt_grand_total.Text))
                {
                    txt_bal.Text = txt_cbalance.Text.ToString();
                    //MessageBox.Show("err");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                con.Close();
            }
        }

        private void txt_grand_total_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //var dash = new customerledger();
            //dash.Show();
        }
    }
}
