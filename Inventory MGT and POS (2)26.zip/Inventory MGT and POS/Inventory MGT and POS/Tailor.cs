﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Taylor : Form
    {
        DataTable dta;
        private MySqlConnection con;
        MySqlCommand cmd;
        public Taylor()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }
        public void load_tailor()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT t_id,t_name,t_phone,t_email,t_adress,t_opnblnc,t_rmnblnc FROM taylor ORDER BY t_id ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "taylor");
            //taylor_table.DataSource = ds.Tables["taylor"];

            MySqlCommand cmd = new MySqlCommand("SELECT t_id,t_name,t_phone,t_email,t_adress,t_opnblnc,t_rmnblnc FROM tailor ORDER BY t_id ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                tailor_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            tailor_table.Columns[0].HeaderText = "ID";
            tailor_table.Columns[1].HeaderText = "Name";
            tailor_table.Columns[2].HeaderText = "Phone";
            tailor_table.Columns[3].HeaderText = "Email";
            tailor_table.Columns[4].HeaderText = "Adress";
            tailor_table.Columns[5].HeaderText = "Opening Balanace";
            tailor_table.Columns[6].HeaderText = "Remaining Balance";

            tailor_table.Columns[0].Width = 40;
            tailor_table.Columns[1].Width = 100;
            tailor_table.Columns[2].Width = 110;
            tailor_table.Columns[3].Width = 90;
            tailor_table.Columns[4].Width = 200;
            tailor_table.Columns[5].Width = 80;
            tailor_table.Columns[6].Width = 80;

            tailor_table.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tailor_table.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            tailor_table.Columns[5].DefaultCellStyle.Format = "N2";
            tailor_table.Columns[6].DefaultCellStyle.Format = "N2";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_name.Text != "" || txt_name.Text == "Taylor Name")
                {
                    cmd = new MySqlCommand("insert into tailor(t_name,t_phone,t_email,t_adress,t_opnblnc,t_rmnblnc) values(@name,@phone,@email,@adress,@opnblnc,@rmnblnc)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@name", txt_name.Text);
                    cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
                    cmd.Parameters.AddWithValue("@email", txt_email.Text);
                    cmd.Parameters.AddWithValue("@adress", txt_adress.Text);
                    cmd.Parameters.AddWithValue("@opnblnc", txt_opnblnc.Text);
                    cmd.Parameters.AddWithValue("@rmnblnc", txt_rmnblnc.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Inserted Successfully");
                    load_tailor();
                }
                else
                {
                    MessageBox.Show("Please Enter Taylor Name");
                }
                txt_name.Clear();
                txt_phone.Clear();
                txt_email.Clear();
                txt_adress.Clear();
                txt_opnblnc.Clear();
                txt_rmnblnc.Clear();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void Taylor_Load(object sender, EventArgs e)
        {
            load_tailor();
        }

        private void txt_search_customer_Leave(object sender, EventArgs e)
        {
            if (txt_search_taylor.Text == "")
            {
                txt_search_taylor.Text = "Search Taylor";
            }
        }

        private void txt_search_taylor_Enter(object sender, EventArgs e)
        {
            if (txt_search_taylor.Text == "Search Taylor")
            {
                txt_search_taylor.Text = "";
            }
        }

        private void txt_search_taylor_KeyUp(object sender, KeyEventArgs e)
        {
            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("t_name LIKE '%" + txt_search_taylor.Text.ToString() + "%' OR t_phone LIKE '%" + txt_search_taylor.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            tailor_table.DataSource = dv;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var dash = new tailor_ledger();
            dash.Show();
        }
    }
}
