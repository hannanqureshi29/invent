﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class preview_product : Form
    {
        private MySqlConnection con;
        DataTable dt = new DataTable();
        public preview_product()
        {
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
            InitializeComponent();
        }

        private void preview_product_Load(object sender, EventArgs e)
        {
            load_product();
        }
        private void load_product()
        {
            try
            {

                MySqlParameter[] pms = new MySqlParameter[2];

                // pms[0] = new MySqlParameter("pid", MySqlDbType.VarChar);
                // pms[0].Value = txt_id.Text;
                pms[0] = new MySqlParameter("suppliername", MySqlDbType.VarChar);
                pms[0].Value = txt_name.Text;
                pms[1] = new MySqlParameter("invonum", MySqlDbType.VarChar);
                pms[1].Value = txt_invoice.Text;

                // pms[3] = new MySqlParameter("pcode", MySqlDbType.VarChar);
                //  pms[3].Value = txt_pcode.Text;

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "load_product1";
                cmd.Parameters.AddRange(pms);

                con.Open();
                using (MySqlDataReader read = cmd.ExecuteReader())

                {
                    if (read.Read())
                    {
                        txt_total.Text = (read["total"]).ToString();
                        txt_gaj.Text = (read["grandgaj"]).ToString();
                        //txt_total.Text = (read["total"]).ToString();

                    }
                   // read.Dispose();
                }
                cmd.Dispose();
                
                MySqlParameter[] prm = new MySqlParameter[2];

                //  prm[0] = new MySqlParameter("pid", MySqlDbType.VarChar);
                //  prm[0].Value = txt_id.Text;
                prm[0] = new MySqlParameter("suppliername", MySqlDbType.VarChar);
                prm[0].Value = txt_name.Text;

                prm[1] = new MySqlParameter("invonum", MySqlDbType.VarChar);
                prm[1].Value = txt_invoice.Text;

                // prm[3] = new MySqlParameter("pcode", MySqlDbType.VarChar);
                // prm[3].Value = txt_pcode.Text;
                //prm[2] = new MySqlParameter("qrevsta", MySqlDbType.VarChar);
                //prm[2].Value = txt_Rev_Sta.Text;

                MySqlCommand cmnd = new MySqlCommand();
                cmnd.Connection = con;
                cmnd.CommandType = CommandType.StoredProcedure;
                cmnd.CommandText = "load_product";
                cmnd.Parameters.AddRange(prm);


                MySqlDataReader sdr = cmnd.ExecuteReader();
                dt.Load(sdr);
                product_tbl.DataSource = dt;
                dt.Dispose();
                sdr.Dispose();
                cmnd.Dispose();


                product_tbl.Columns[0].HeaderText = "ID";
                product_tbl.Columns[1].HeaderText = "Code";
                product_tbl.Columns[2].HeaderText = "Gaj";
                product_tbl.Columns[3].HeaderText = "Purchase Price";

                //sale_record_table.Columns[4].HeaderText = "Unit Price";
                //sale_record_table.Columns[5].HeaderText = "QTY";
                //sale_record_table.Columns[6].HeaderText = "Total%";
                //Products_Table.Columns[7].HeaderText = "Unit Price";
                //Products_Table.Columns[8].HeaderText = "Total";


                product_tbl.Columns[0].Width = 150;
                product_tbl.Columns[1].Width = 150;
                product_tbl.Columns[2].Width = 200;
                product_tbl.Columns[3].Width = 200;
                //sale_record_table.Columns[4].Width = 100;
                //sale_record_table.Columns[5].Width = 50;
                //sale_record_table.Columns[6].Width = 100;
            }
            catch (Exception exc)
            {
                con.Close();
                MessageBox.Show(exc.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
