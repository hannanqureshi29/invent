﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Inventory_MGT_and_POS
{
    public partial class Purchases_table : Form
    {
        DataTable dta;
        private MySqlConnection con;

        public static DataTable DataSource { get; private set; }

        public Purchases_table()
        {
            InitializeComponent();
            con = new MySqlConnection("Server =localhost; Port =3306; Database =pos; user id =root; password =; Connection Reset=false;convert zero datetime = True;SslMode=None;");
        }

        private void Purchases_Load(object sender, EventArgs e)
        {
            load_purchase();
            //  search_from_customer();
        }
        public void load_purchase()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT DISTINCT invoice_num,pur_date,sp_id,c_name,total_items,grand_total,cashier_name FROM purchase ORDER BY invoice_num ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "purchase");
            //purchase_table.DataSource = ds.Tables["purchase"];
            MySqlCommand cmd = new MySqlCommand("SELECT DISTINCT invoice_num,pur_date,sp_id,c_name,total_items,grand_total,cashier_name FROM purchase ORDER BY invoice_num ASC", con);
            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmd;
                dta = new DataTable();
                sda.Fill(dta);
                BindingSource bsource = new BindingSource();

                bsource.DataSource = dta;
                purchase_table.DataSource = bsource;
                sda.Update(dta);
            }
            catch (Exception ex)
            {
                //con.Close();
                MessageBox.Show(ex.Message);
            }

            purchase_table.DataSource = dta;
            purchase_table.Columns[0].HeaderText = "Invoice #";
            purchase_table.Columns[1].HeaderText = "Date";
            purchase_table.Columns[2].HeaderText = "SP ID";
            purchase_table.Columns[3].HeaderText = "Suppliers Name";
            purchase_table.Columns[4].HeaderText = "Total Items";
            purchase_table.Columns[5].HeaderText = "Grand Total";
            purchase_table.Columns[6].HeaderText = "Cashier Name";

            purchase_table.Columns[0].Width = 40;
            purchase_table.Columns[1].Width = 90;
            purchase_table.Columns[2].Width = 40;
            purchase_table.Columns[3].Width = 120;
            purchase_table.Columns[4].Width = 50;
            purchase_table.Columns[5].Width = 150;
            purchase_table.Columns[6].Width = 100;

            purchase_table.Columns[5].DefaultCellStyle.Format = "N2";

            purchase_table.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            purchase_table.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            purchase_table.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private void search_purchase()
        {
            //MySqlDataAdapter da = new MySqlDataAdapter("SELECT DISTINCT invoice_num,s_date,c_name,total_items,grand_total,cashier_name FROM purchase WHERE invoice_num like '" + txt_search.Text + "%' OR c_name like '" + txt_search.Text + "%' OR cashier_name like '" + txt_search.Text + "%' ORDER BY invoice_num ASC", con);
            //DataSet ds = new DataSet();
            //da.Fill(ds, "purchase");
            //purchase_table.DataSource = ds.Tables["purchase"];
            //purchase_table.Columns[0].HeaderText = "Invoice #";
            //purchase_table.Columns[1].HeaderText = "Date";
            //purchase_table.Columns[2].HeaderText = "Customer Name";
            //purchase_table.Columns[3].HeaderText = "Total Items";
            //purchase_table.Columns[4].HeaderText = "Grand Total";
            //purchase_table.Columns[5].HeaderText = "Cashier Name";

            //purchase_table.Columns[0].Width = 60;
            //purchase_table.Columns[1].Width = 90;
            //purchase_table.Columns[2].Width = 120;
            //purchase_table.Columns[3].Width = 50;
            //purchase_table.Columns[4].Width = 150;
            //purchase_table.Columns[5].Width = 100;

            //purchase_table.Columns[4].DefaultCellStyle.Format = "N2";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //if ((txt_search.Text != "") || (txt_search.Text != "Search purchase Record"))
            //{
            //    search_purchase();
            //}
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search purchase Record";
            }
        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search purchase Record")
            {
                txt_search.Text = "";
            }
        }
        //private void search_from_customer()
        //{
        //    MySqlCommand cmd = new MySqlCommand("SELECT * FROM purchase ", con);
        //    //  SELECT quotations.q_num,customer.company_name,customer.contact_person FROM quotations INNER JOIN customer ON quotations.c_id = customer.c_id
        //    con.Open();
        //    MySqlDataReader reader = cmd.ExecuteReader();
        //    AutoCompleteStringCollection collection = new AutoCompleteStringCollection();

        //    while (reader.Read())
        //    {
        //        collection.Add(reader.GetString(1));
        //        collection.Add(reader.GetString(4));
        //        collection.Add(reader.GetString(19));
        //        // collection.Add(reader.GetString(3));
        //        // collection.Add(reader.GetString(4));
        //    }
        //    txt_search.AutoCompleteCustomSource = collection;
        //    con.Close();
        //}

        private void txt_search_KeyDown(object sender, KeyEventArgs e)
        {
            // search_purchase();
        }

        private void purchase_table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            preview_purchase edt = new preview_purchase();
            int row = purchase_table.CurrentRow.Index;

            edt.lbl_invoice_num.Text = Convert.ToString(purchase_table[0, row].Value);
            edt.txt_sid.Text = Convert.ToString(purchase_table[2, row].Value);
            // edt.txt_cbalance.Text = Convert.ToString(sales_table[2, row].Value);
            //edt.txt_Rev_Sta.Text = Convert.ToString(TableProducts[3, row].Value);
            edt.Show();
        }

        private void txt_search_KeyUp(object sender, KeyEventArgs e)
        {

            DataView dv = new DataView(dta);

            dv.RowFilter = string.Concat("invoice_num LIKE '%" + txt_search.Text.ToString() + "%' OR c_name LIKE '%" + txt_search.Text.ToString() + "%' OR cashier_name LIKE '%" + txt_search.Text.ToString() + "%'"); //OR p_unit '%{1}%'
            purchase_table.DataSource = dv;
        }
    }
}
